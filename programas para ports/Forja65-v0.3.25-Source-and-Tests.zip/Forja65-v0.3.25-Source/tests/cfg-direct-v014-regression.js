const F=require('../forja65-core.js');
function fail(m){throw new Error(m)}
const d=F.makeSyntheticRom();
// $008000: CLC; BCC $8007; LDA #$01; BRA $8009; LDA #$02; JSR $8020; RTS
// $008020: INX; RTS
const code=[0x18,0x90,0x04,0xA9,0x01,0x80,0x02,0xA9,0x02,0x20,0x20,0x80,0x60];
d.set(code,0);d.set([0xE8,0x60],0x20);
const rom=F.loadRom(d,'cfg-v014.sfc');
const a=F.analyze(rom,512);
if(a.cfgFunctions!==2)fail(`cfgFunctions esperado 2, veio ${a.cfgFunctions}`);
if(a.cfgCalls!==1)fail(`cfgCalls esperado 1, veio ${a.cfgCalls}`);
if(a.unsupported!==0||a.partial!==0)fail(`esperado CPU direta sem partial/unsupported, veio p=${a.partial} u=${a.unsupported}`);
for(const pc of [0x8001,0x8005,0x8009]){
  const i=a.instructions.find(x=>x.pc===pc);if(!i||i.status!=='native')fail(`flow $${pc.toString(16)} nao ficou native`);
}
const p=F.generateProject(rom,a),g=Object.entries(p).filter(([k])=>k==='src/dispatch.cpp'||/^src\/generated_\d+\.cpp$/.test(k)).map(([,v])=>String(v)).join('\n');
if(!/if \(!cpu\.c\) \{ hw\.addCpuInternalCycles\(1u\); goto L_008007; \}/.test(g))fail('branch C++ com timing nao emitido');
if(!g.includes('goto L_008009;'))fail('BRA C++ nao emitido');
if(!g.includes('forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8020u), 0x008009u);'))fail('JSR nao virou chamada C++ state-aware preservando PB runtime');
if(/fetch|decode|switch\s*\(.*opcode/i.test(g))fail('dispatcher de opcode apareceu no C++ gerado');
console.log('CFG direct v0.1.4 regression: PASS', {functions:a.cfgFunctions,blocks:a.cfgBlocks,edges:a.cfgEdges,calls:a.cfgCalls,decoded:a.decoded});
