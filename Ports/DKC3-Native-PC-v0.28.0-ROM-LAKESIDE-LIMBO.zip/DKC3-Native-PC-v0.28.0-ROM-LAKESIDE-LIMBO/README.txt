DKC3 NATIVE PC v0.28.0 - ROM LAKESIDE LIMBO PASS
=================================================

O runtime C++ usa a ROM fornecida pelo usuario como fonte dos dados originais.
Nao e necessario Mesen, Oracle, save-state ou sistema de captura para jogar.

ROM desta base
  rom/dkc3_ptbr.sfc
  4194304 bytes
  CRC32 448EEC19
  SHA-256 2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b

FLUXO ATUAL
  Title original da ROM
    -> File Select original da ROM
    -> Northern Kremisphere original
    -> Lake Orangatanga original
    -> Lakeside Limbo ROM-first
    -> Doorstop Dash
    -> Tidal Trouble

NOVO NA v0.28
  * Lakeside Limbo adicionada ao catalogo jogavel.
  * 6240 px de terreno reconstruidos diretamente de RiverbankLevels + Map32.
  * Layer 1/Layer 2/paleta lidos e descompactados da ROM no runtime.
  * 47 placements originais lidos da tabela da fase.
  * Checkpoint e saida para Doorstop funcionando.
  * Novo `rom_scene` permite fase renderizada diretamente dos dados do cartucho.

O QUE AINDA NAO E 100% FIEL EM LAKESIDE
  * A colisao de travessia ainda e um scaffold horizontal.
  * Os 47 placements ja sao decodificados, mas seus tipos ainda nao estao todos
    traduzidos para inimigos/barris/bonus nativos.
  * Os dois bonus rooms ainda nao sao jogaveis.

PROGRESSAO DO PRIMEIRO MUNDO
  Lakeside Limbo -> Doorstop Dash -> Tidal Trouble -> Skidda's Row ->
  Murky Mill -> Belcha's Barn.

BUILD WINDOWS
  Execute BUILD-WINDOWS.cmd.
  Ele gera `bin/` com o executavel, assets, ROM e arquivos necessarios ao jogo.
  `bin/` nao recebe `src`, `tests`, `docs`, Mesen, Oracle, capturas ou save-states.
