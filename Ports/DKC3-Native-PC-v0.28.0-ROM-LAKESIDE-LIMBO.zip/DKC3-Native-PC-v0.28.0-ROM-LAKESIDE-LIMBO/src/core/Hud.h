#pragma once
#include <cstdint>
#include <string>
namespace dkc3 {
// Utilitarios 2D minimos do runtime nativo (sem GDI): fonte bitmap 5x7, caixas translucidas e contornos.
// Todos operam direto no framebuffer BGRA 0xAARRGGBB usado pelo renderer.
std::string hudSanitize(const std::string& text);              // maiusculas, sem acentos, so ASCII conhecido
int hudTextWidth(const std::string& text, int scale = 1);
void hudDrawText(uint32_t* dst, int w, int h, int x, int y, const std::string& text, uint32_t color, int scale = 1, bool shadow = true);
void hudFillRect(uint32_t* dst, int w, int h, int x, int y, int rw, int rh, uint32_t rgb, int alpha /*0..255*/);
void hudOutlineRect(uint32_t* dst, int w, int h, int x, int y, int rw, int rh, uint32_t rgb);
}
