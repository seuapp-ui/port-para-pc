#include "Player.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
static void approach(float& v,float target,float amount){ if(v<target) v=std::min(v+amount,target); else if(v>target) v=std::max(v-amount,target); }
void updatePlayer(Player& p,const InputState& in,float dt,const Rect* solids,int solidCount){
  if(p.motion==PlayerMotion::Hang){p.vel={};p.grounded=false;return;}
  const float maxSpeed = in.run ? 150.0f : 95.0f;
  const float accel = p.grounded ? 650.0f : 360.0f;
  const float friction = p.grounded ? 900.0f : 120.0f;
  float target=0;
  if(in.left!=in.right){ target=in.left?-maxSpeed:maxSpeed; p.facingRight=!in.left; approach(p.vel.x,target,accel*dt); }
  else approach(p.vel.x,0.0f,friction*dt);
  // v0.8.0: pulo por borda de subida + coyote time + buffer + altura variavel.
  p.justJumped=false;
  const float kCoyote=0.09f,kBuffer=0.10f,kJumpSpeed=-255.0f,kCutSpeed=-120.0f,kMinHold=0.05f;
  const bool jumpPressed=in.jump&&!p.jumpWasDown;p.jumpWasDown=in.jump;
  p.coyoteTimer=p.grounded?kCoyote:std::max(0.0f,p.coyoteTimer-dt);
  p.jumpBuffer=jumpPressed?kBuffer:std::max(0.0f,p.jumpBuffer-dt);
  if(p.jumpBuffer>0.0f && (p.grounded||p.coyoteTimer>0.0f)){ p.vel.y=kJumpSpeed; p.grounded=false; p.coyoteTimer=0.0f; p.jumpBuffer=0.0f; p.jumping=true; p.jumpTime=0.0f; p.justJumped=true; }
  if(p.jumping){ p.jumpTime+=dt; if(p.vel.y>=0.0f)p.jumping=false; else if(!in.jump&&p.jumpTime>=kMinHold&&p.vel.y<kCutSpeed)p.vel.y=kCutSpeed; }
  p.vel.y = std::min(p.vel.y + 720.0f*dt, 420.0f);

  p.pos.x += p.vel.x*dt;
  Rect b=p.bounds();
  for(int i=0;i<solidCount;i++) if(overlaps(b,solids[i])){
    if(p.vel.x>0) p.pos.x=solids[i].x-p.width; else if(p.vel.x<0) p.pos.x=solids[i].x+solids[i].w;
    p.vel.x=0; b=p.bounds();
  }

  p.pos.y += p.vel.y*dt;
  p.grounded=false; b=p.bounds();
  for(int i=0;i<solidCount;i++) if(overlaps(b,solids[i])){
    if(p.vel.y>0){ p.pos.y=solids[i].y-p.height; p.grounded=true; }
    else if(p.vel.y<0) p.pos.y=solids[i].y+solids[i].h;
    p.vel.y=0; b=p.bounds();
  }
  p.motion=p.grounded?PlayerMotion::Ground:PlayerMotion::Air;
}
}

namespace dkc3 {
void updateSwimPlayer(Player& p,const InputState& in,float dt,const Rect* solids,int solidCount,Vec2 current){
  if(p.motion==PlayerMotion::Hang){p.vel={};p.grounded=false;return;}
  p.justJumped=false;p.jumpWasDown=in.jump;p.jumping=false;p.coyoteTimer=0.0f;p.jumpBuffer=0.0f;
  const float maxX=in.run?105.0f:78.0f,maxY=86.0f,accel=310.0f,drag=250.0f;
  float tx=0.0f,ty=18.0f;
  if(in.left!=in.right){tx=in.left?-maxX:maxX;p.facingRight=!in.left;}
  if(in.up!=in.down)ty=in.up?-maxY:maxY;
  if(in.jump)ty=-112.0f;
  // Correnteza altera o alvo do nado: contra a corrente o avanco cai, a favor aumenta,
  // e sem input o jogador deriva naturalmente. Limites evitam correntes absurdas no arquivo de fase.
  tx+=std::clamp(current.x,-70.0f,70.0f);ty+=std::clamp(current.y,-55.0f,55.0f);
  tx=std::clamp(tx,-145.0f,145.0f);ty=std::clamp(ty,-145.0f,145.0f);
  approach(p.vel.x,tx,(std::fabs(tx)<0.01f?drag:accel)*dt);approach(p.vel.y,ty,230.0f*dt);
  p.pos.x+=p.vel.x*dt;Rect b=p.bounds();
  for(int i=0;i<solidCount;i++)if(overlaps(b,solids[i])){if(p.vel.x>0)p.pos.x=solids[i].x-p.width;else if(p.vel.x<0)p.pos.x=solids[i].x+solids[i].w;p.vel.x=0;b=p.bounds();}
  p.pos.y+=p.vel.y*dt;b=p.bounds();
  for(int i=0;i<solidCount;i++)if(overlaps(b,solids[i])){if(p.vel.y>0)p.pos.y=solids[i].y-p.height;else if(p.vel.y<0)p.pos.y=solids[i].y+solids[i].h;p.vel.y=0;b=p.bounds();}
  p.grounded=false;p.motion=PlayerMotion::Swim;
}
}
