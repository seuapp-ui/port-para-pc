#include "NativeScene.h"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
namespace dkc3 {
namespace fs=std::filesystem;
#pragma pack(push,1)
struct TileHeader{char magic[4];uint16_t version,bpp;uint32_t tileCount,tileW,tileH,charBaseWord;};
struct MapHeader{char magic[4];uint16_t version,reserved;uint32_t width,height,mapBaseWord;};
struct PalHeader{char magic[4];uint16_t version,colors;};
#pragma pack(pop)
static bool readTiles(const fs::path&p,NativeTileSet&o){std::ifstream f(p,std::ios::binary);TileHeader h{};f.read((char*)&h,sizeof h);if(!f||memcmp(h.magic,"NTIL",4)||h.version!=1||h.tileW!=8||h.tileH!=8||!h.tileCount)return false;o.bpp=h.bpp;o.tileCount=h.tileCount;o.pixels.resize((size_t)h.tileCount*64);f.read((char*)o.pixels.data(),o.pixels.size());return bool(f);}
static bool readMap(const fs::path&p,NativeTileMap&o){std::ifstream f(p,std::ios::binary);MapHeader h{};f.read((char*)&h,sizeof h);if(!f||memcmp(h.magic,"NMAP",4)||h.version!=1||!h.width||!h.height)return false;o.width=(int)h.width;o.height=(int)h.height;o.entries.resize((size_t)o.width*o.height);f.read((char*)o.entries.data(),std::streamsize(o.entries.size()*2));return bool(f);}
static bool readPal(const fs::path&p,std::vector<uint16_t>&o){std::ifstream f(p,std::ios::binary);PalHeader h{};f.read((char*)&h,sizeof h);if(!f||memcmp(h.magic,"NPAL",4)||h.version!=1||h.colors==0)return false;o.resize(h.colors);f.read((char*)o.data(),std::streamsize(o.size()*2));return bool(f);}
bool loadNativeScene(const std::string& path, NativeScene& out){out={};std::ifstream f(path);if(!f)return false;fs::path base=fs::path(path).parent_path();std::string line,paletteFile="palette.npal";while(std::getline(f,line)){if(line.empty()||line[0]=='#')continue;std::istringstream ss(line);std::string k;ss>>k;if(k=="NATIVE_SCENE"){int v;ss>>v;if(v!=1)return false;}else if(k=="mode")ss>>out.mode;else if(k=="bg3_priority"){int v;ss>>v;out.bg3Priority=v!=0;}else if(k=="tm"){int v;ss>>v;out.tm=(uint8_t)v;}else if(k=="ts"){int v;ss>>v;out.ts=(uint8_t)v;}else if(k=="cgwsel"){int v;ss>>v;out.cgwsel=(uint8_t)v;}else if(k=="cgadsub"){int v;ss>>v;out.cgadsub=(uint8_t)v;}else if(k=="fixed_color"){int v;ss>>v;out.fixedColor=(uint16_t)v;}else if(k=="brightness")ss>>out.brightness;else if(k=="backdrop")ss>>out.backdrop;else if(k=="viewport")ss>>out.viewportW>>out.viewportH;else if(k=="palette")ss>>paletteFile;else if(k=="layer"){NativeLayer l;int mw,mh,en;std::string tf,mf;ss>>l.name>>l.bpp>>mw>>mh>>l.scrollX>>l.scrollY>>en>>tf>>mf;l.enabled=en!=0;if(!readTiles(base/tf,l.tiles)||!readMap(base/mf,l.map))return false;if(l.tiles.bpp!=l.bpp||l.map.width!=mw||l.map.height!=mh)return false;out.layers.push_back(std::move(l));}}
return readPal(base/paletteFile,out.palette)&&!out.layers.empty();}
static uint32_t color15(uint16_t c,int brightness=15){
  auto cv=[&](int v){int q=(v<<3)|(v>>2);return uint8_t((q*std::clamp(brightness,0,15)+7)/15);};
  uint8_t r=cv(c&31),g=cv((c>>5)&31),b=cv((c>>10)&31);return 0xff000000u|(uint32_t(r)<<16)|(uint32_t(g)<<8)|uint32_t(b);
}
static int layerZ(const NativeScene&s,int layer,bool high){if(s.mode==1){if(s.bg3Priority){static constexpr int lo[3]={5,4,1},hi[3]={8,7,10};return high?hi[std::min(layer,2)]:lo[std::min(layer,2)];}static constexpr int lo[3]={6,5,1},hi[3]={9,8,3};return high?hi[std::min(layer,2)]:lo[std::min(layer,2)];}return high?8:4;}
struct ScreenPixel{uint16_t color=0;uint8_t z=0;uint8_t layerBit=0x20;};
static inline uint16_t math15(uint16_t a,uint16_t b,bool sub,bool half){
  int ar=a&31,ag=(a>>5)&31,ab=(a>>10)&31,br=b&31,bg=(b>>5)&31,bb=(b>>10)&31;
  auto ch=[&](int x,int y){int v=sub?x-y:x+y;if(sub)v=std::max(0,v);else v=std::min(31,v);if(half)v>>=1;return v;};
  return uint16_t(ch(ar,br)|(ch(ag,bg)<<5)|(ch(ab,bb)<<10));
}
static void renderScreen(const NativeScene&s,std::vector<ScreenPixel>&out,int w,int h,int cameraX,int cameraY,uint8_t mask,bool /*mainScreen*/){
  out.assign((size_t)w*h,ScreenPixel{(uint16_t)s.palette[std::clamp(s.backdrop,0,(int)s.palette.size()-1)],0,0x20});
  for(size_t li=0;li<s.layers.size();++li){const auto&l=s.layers[li];if(!(mask&(1u<<li))||l.map.width<=0||l.map.height<=0)continue;const int mapPxW=l.map.width*8,mapPxH=l.map.height*8,palStride=1<<l.bpp;
    for(int y=0;y<h;y++){int wy=(y+l.scrollY+1+cameraY)%mapPxH;if(wy<0)wy+=mapPxH;int ty=wy>>3,py=wy&7;for(int x=0;x<w;x++){int wx=(x+l.scrollX+cameraX)%mapPxW;if(wx<0)wx+=mapPxW;int tx=wx>>3,px=wx&7;uint16_t e=l.map.entries[(size_t)ty*l.map.width+tx];uint32_t tile=e&0x3ffu;if(tile>=l.tiles.tileCount)continue;int sx=(e&0x4000)?7-px:px,sy=(e&0x8000)?7-py:py;uint8_t pix=l.tiles.pixels[(size_t)tile*64+sy*8+sx];if(!pix)continue;int zz=layerZ(s,(int)li,(e&0x2000)!=0);size_t di=(size_t)y*w+x;if(zz<=out[di].z)continue;int pal=(e>>10)&7;int ci=pal*palStride+pix;if((unsigned)ci>=s.palette.size())continue;out[di].z=(uint8_t)zz;out[di].color=s.palette[ci];out[di].layerBit=uint8_t(1u<<li);}}
  }
}
void renderNativeScene(const NativeScene&s,uint32_t*dst,int w,int h,int cameraX,int cameraY){
  if(!dst||w<=0||h<=0||s.palette.empty())return;
  // v0.10.0: scratch persistente por thread; evita duas alocacoes grandes a cada frame.
  static thread_local std::vector<ScreenPixel> mainPx,subPx;renderScreen(s,mainPx,w,h,cameraX,cameraY,s.tm,true);renderScreen(s,subPx,w,h,cameraX,cameraY,s.ts,false);
  const bool useSub=(s.cgwsel&0x02)!=0,subtract=(s.cgadsub&0x80)!=0,half=(s.cgadsub&0x40)!=0;
  for(size_t i=0,n=(size_t)w*h;i<n;i++){
    uint16_t c=mainPx[i].color;const uint8_t mathBit=mainPx[i].layerBit;
    if((s.cgadsub&mathBit)!=0){uint16_t b=useSub?(subPx[i].z?subPx[i].color:s.fixedColor):s.fixedColor;c=math15(c,b,subtract,half);}
    dst[i]=color15(c,s.brightness);
  }
}
uint64_t hashFrame(const uint32_t*p,size_t n){uint64_t h=1469598103934665603ull;const uint8_t*b=(const uint8_t*)p;for(size_t i=0;i<n*sizeof(uint32_t);i++){h^=b[i];h*=1099511628211ull;}return h;}
}
