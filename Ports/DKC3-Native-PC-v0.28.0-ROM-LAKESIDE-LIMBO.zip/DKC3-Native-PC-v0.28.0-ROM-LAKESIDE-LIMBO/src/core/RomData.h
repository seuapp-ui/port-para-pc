#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace dkc3 {

struct RomInfo {
  bool valid=false;
  std::string path;
  std::string title;
  uint32_t crc32=0;
  size_t size=0;
};

class RomImage {
 public:
  bool load(const std::string& path);
  bool loadFirstAvailable(const std::vector<std::string>& paths);
  const RomInfo& info() const { return info_; }
  bool range(size_t begin,size_t end,std::vector<uint8_t>& out) const;
  const std::vector<uint8_t>& bytes() const { return data_; }
 private:
  std::vector<uint8_t> data_;
  RomInfo info_{};
};

bool dkc3BigDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed=nullptr);
bool dkc3SmallDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed=nullptr);

struct RomLayer {
  int widthTiles=0;
  int heightTiles=0;
  std::vector<uint8_t> gfx4bpp;
  std::vector<uint8_t> tilemap;
  std::vector<uint8_t> palette;
  bool transparentZero=false;
  int bpp=4;
  bool snesScreenBlocks=false;
};

bool renderSnes4bppLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX=0,int dstY=0);
bool renderSnesLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX=0,int dstY=0,std::vector<uint8_t>* opaqueMask=nullptr);

class RomFrontendVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  const std::vector<uint32_t>& title() const { return title_; }
  const std::vector<uint32_t>& fileSelect() const { return fileSelect_; }
  int titleW() const { return 256; }
  int titleH() const { return 224; }
  std::string status() const;
 private:
  bool valid_=false;
  RomInfo info_{};
  std::vector<uint32_t> title_;
  std::vector<uint32_t> fileSelect_;
};

struct RomSpriteFrame {
  int width=0;
  int height=0;
  int anchorX=0;
  int anchorY=0;
  std::vector<uint32_t> pixels;
};



struct RomLevelPlacement {
  uint16_t parameter=0;
  uint16_t x=0;
  uint16_t y=0;
  uint16_t type=0;
};

class RomLakesideLimboVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  int width() const { return width_; }
  int height() const { return height_; }
  const std::vector<uint32_t>& pixels() const { return pixels_; }
  const std::vector<uint8_t>& foregroundMask() const { return foregroundMask_; }
  const std::vector<RomLevelPlacement>& placements() const { return placements_; }
  const std::vector<uint8_t>& placementData() const { return placementData_; }
 private:
  bool valid_=false;
  RomInfo info_{};
  int width_=6240;
  int height_=224;
  std::vector<uint32_t> pixels_;
  std::vector<uint8_t> foregroundMask_;
  std::vector<RomLevelPlacement> placements_;
  std::vector<uint8_t> placementData_;
};

class RomLakeOrangatangaVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  int width() const { return 256; }
  int height() const { return 224; }
  const std::vector<uint32_t>& mapPixels() const { return map_; }
  const std::vector<uint8_t>& collisionData() const { return collision_; }
  const std::vector<RomSpriteFrame>& dixieWalkFrames() const { return dixieWalkFrames_; }
 private:
  bool valid_=false;
  RomInfo info_{};
  std::vector<uint32_t> map_;
  std::vector<uint8_t> collision_;
  std::vector<RomSpriteFrame> dixieWalkFrames_;
};

class RomWorldMapVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  int width() const { return width_; }
  int height() const { return height_; }
  const std::vector<uint32_t>& mapPixels() const { return map_; }
  const std::vector<uint8_t>& landMask() const { return landMask_; }
  const std::vector<RomSpriteFrame>& boatFrames() const { return boatFrames_; }
  bool landAt(int x,int y) const;
  bool boatBlocked(float x,float y,int halfW=7,int halfH=7) const;
 private:
  bool valid_=false;
  RomInfo info_{};
  int width_=512;
  int height_=512;
  std::vector<uint32_t> map_;
  std::vector<uint8_t> landMask_;
  std::vector<RomSpriteFrame> boatFrames_;
};

}
