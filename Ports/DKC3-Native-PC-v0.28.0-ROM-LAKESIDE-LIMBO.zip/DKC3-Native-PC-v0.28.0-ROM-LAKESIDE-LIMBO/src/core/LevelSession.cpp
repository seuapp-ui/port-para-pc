#include "LevelSession.h"
#include <filesystem>
#include <fstream>
#include <sstream>
namespace dkc3 {
bool LevelCatalog::load(const std::string& path){
  entries_.clear();std::ifstream f(path);if(!f)return false;const auto base=std::filesystem::path(path).parent_path();std::string line;
  while(std::getline(f,line)){if(line.empty()||line[0]=='#')continue;std::istringstream ss(line);std::string k,id,p;if(!(ss>>k>>id>>p)||k!="level")continue;LevelCatalogEntry e;e.id=id;e.path=(base/p).lexically_normal().string();entries_[id]=std::move(e);}
  return !entries_.empty();
}
const LevelCatalogEntry* LevelCatalog::find(const std::string& id)const{auto i=entries_.find(id);return i==entries_.end()?nullptr:&i->second;}
bool GameSession::loadLevel(const std::string& id,const GamePersistentState* persistent){
  const auto* e=catalog_.find(id);if(!e)return false;Game next;if(!next.init(e->path.c_str(),persistent))return false;next.setHudEnabled(game_.hudEnabled());next.setDebugOverlay(game_.debugOverlay());game_=std::move(next);currentLevel_=id;return true;
}
bool GameSession::init(const std::string& catalogPath,const std::string& startLevel,const GamePersistentState* persistent){transitions_=0;currentLevel_.clear();exitPending_.clear();return catalog_.load(catalogPath)&&loadLevel(startLevel,persistent);}
void GameSession::step(const InputState& in,float dt){
  game_.step(in,dt);{auto ev=game_.takeSfx();sfx_.insert(sfx_.end(),ev.begin(),ev.end());if(sfx_.size()>64)sfx_.erase(sfx_.begin(),sfx_.end()-64);}const std::string target=game_.pendingLevel();if(target.empty()||target==currentLevel_)return;
  if(!autoTransitions_){if(exitPending_.empty())exitPending_=target;return;}
  const GamePersistentState keep=game_.persistentState();if(loadLevel(target,&keep))++transitions_;
}
bool GameSession::restart(){if(currentLevel_.empty())return false;exitPending_.clear();const bool hud=game_.hudEnabled(),dbg=game_.debugOverlay();const std::string id=currentLevel_;if(!loadLevel(id,nullptr))return false;game_.setHudEnabled(hud);game_.setDebugOverlay(dbg);return true;}
}
