#include "RomData.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <sstream>

namespace dkc3 {
namespace {
uint32_t crc32(const uint8_t* p,size_t n){
  uint32_t c=0xffffffffu;
  for(size_t i=0;i<n;++i){c^=p[i];for(int b=0;b<8;++b)c=(c>>1)^(0xedb88320u&(~(c&1u)+1u));}
  return c^0xffffffffu;
}
uint32_t bgr555(uint16_t v){
  const uint32_t r=(v&31u)*255u/31u;
  const uint32_t g=((v>>5)&31u)*255u/31u;
  const uint32_t b=((v>>10)&31u)*255u/31u;
  return (r<<16)|(g<<8)|b;
}
size_t hiromToPc(uint32_t snes){
  const uint32_t bank=(snes>>16)&0xffu;
  return (size_t)(bank-0xc0u)*0x10000u+(size_t)(snes&0xffffu);
}
struct NibbleReader{
  const uint8_t* d=nullptr;size_t n=0,pos=0;bool high=true;
  int nib(){if(pos>=n)return -1;int v=high?(d[pos]>>4):(d[pos]&15);if(!high)++pos;high=!high;return v;}
  int byte(){int a=nib(),b=nib();return (a<0||b<0)?-1:((a<<4)|b);}
};

bool loadRom(const std::string& romPath,RomImage& rom){
  if(!romPath.empty())return rom.load(romPath)&&rom.info().valid;
  return rom.loadFirstAvailable({"rom/dkc3_ptbr.sfc","dkc3_ptbr.sfc","input/dkc3_ptbr.sfc","../rom/dkc3_ptbr.sfc"});
}

size_t tilemapEntryIndex(const RomLayer& layer,int tx,int ty){
  if(!layer.snesScreenBlocks)return (size_t)ty*(size_t)layer.widthTiles+(size_t)tx;
  const int screensX=(layer.widthTiles+31)/32;
  const int sx=tx/32,sy=ty/32;
  return (size_t)(sy*screensX+sx)*1024u+(size_t)(ty&31)*32u+(size_t)(tx&31);
}

struct DynamicPoseSpec{uint32_t headerStart=0,gfxStart=0,gfxEnd=0;};
struct DynamicPiece{int x=0,y=0,w=0,h=0;std::vector<uint32_t> pixels;};

std::array<uint32_t,16> loadSpritePalette(const RomImage& rom,uint32_t start,uint32_t end){
  std::array<uint32_t,16> pal{};pal[0]=0;
  const auto& bytes=rom.bytes();const size_t a=hiromToPc(start),b=hiromToPc(end);
  size_t pi=1;
  for(size_t p=a;p+1<b&&p+1<bytes.size()&&pi<pal.size();p+=2,++pi){
    pal[pi]=0xff000000u|bgr555((uint16_t)(bytes[p]|(bytes[p+1]<<8)));
  }
  return pal;
}

bool decodeObjTile(const std::vector<uint8_t>& gfx,size_t off,const std::array<uint32_t,16>& pal,std::vector<uint32_t>& tile){
  if(off+32>gfx.size())return false;
  tile.assign(64,0);
  for(int y=0;y<8;++y){
    const uint8_t p0=gfx[off+y*2],p1=gfx[off+y*2+1],p2=gfx[off+16+y*2],p3=gfx[off+16+y*2+1];
    for(int x=0;x<8;++x){const int bit=7-x;const int ci=((p0>>bit)&1)|(((p1>>bit)&1)<<1)|(((p2>>bit)&1)<<2)|(((p3>>bit)&1)<<3);tile[(size_t)y*8u+(size_t)x]=pal[(size_t)ci];}
  }
  return true;
}

bool decodeDynamicPose(const RomImage& rom,const DynamicPoseSpec& spec,const std::array<uint32_t,16>& pal,std::vector<DynamicPiece>& pieces){
  pieces.clear();std::vector<uint8_t> hdr,gfx;
  if(!rom.range(hiromToPc(spec.headerStart),hiromToPc(spec.gfxStart),hdr)||!rom.range(hiromToPc(spec.gfxStart),hiromToPc(spec.gfxEnd),gfx)||hdr.size()<10)return false;
  std::vector<int> counts;size_t pairBase=0;
  if(hdr[8]<0x10){if(hdr.size()<14)return false;counts={hdr[0],hdr[1],hdr[3],hdr[8],hdr[10],hdr[12]};pairBase=14;}
  else{counts={hdr[0],hdr[1],hdr[3]};pairBase=8;}
  int total=0;for(int c:counts)total+=c;if(pairBase+(size_t)total*2u>hdr.size())return false;
  size_t gfxOff=0;int pieceIndex=0;
  for(size_t group=0;group<counts.size();++group){
    const bool big=(group%3u)==0u;
    for(int n=0;n<counts[group];++n){
      DynamicPiece p;p.x=(int)hdr[pairBase+(size_t)pieceIndex*2u]-0x80;p.y=(int)hdr[pairBase+(size_t)pieceIndex*2u+1u]-0x80;++pieceIndex;
      if(big){
        p.w=p.h=16;p.pixels.assign(256,0);
        for(int ti=0;ti<4;++ti){std::vector<uint32_t> tile;if(!decodeObjTile(gfx,gfxOff+(size_t)ti*32u,pal,tile))return false;const int ox=(ti&1)*8,oy=(ti>>1)*8;for(int y=0;y<8;++y)for(int x=0;x<8;++x)p.pixels[(size_t)(oy+y)*16u+(size_t)(ox+x)]=tile[(size_t)y*8u+(size_t)x];}
        gfxOff+=128;
      }else{
        p.w=p.h=8;if(!decodeObjTile(gfx,gfxOff,pal,p.pixels))return false;gfxOff+=32;
      }
      pieces.push_back(std::move(p));
    }
  }
  return gfxOff<=gfx.size();
}

void blitPieces(const std::vector<DynamicPiece>& pieces,RomSpriteFrame& frame){
  for(const auto& p:pieces)for(int y=0;y<p.h;++y)for(int x=0;x<p.w;++x){
    const uint32_t c=p.pixels[(size_t)y*(size_t)p.w+(size_t)x];if((c>>24)==0)continue;
    const int dx=frame.anchorX+p.x+x,dy=frame.anchorY+p.y+y;if(dx>=0&&dy>=0&&dx<frame.width&&dy<frame.height)frame.pixels[(size_t)dy*(size_t)frame.width+(size_t)dx]=c;
  }
}

bool buildBoatFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec boat[9]={
    {0xCA42D9,0xCA42EB,0xCA43EB},{0xCA43EB,0xCA43FD,0xCA44FD},{0xCA44FD,0xCA4509,0xCA4609},
    {0xCA4609,0xCA4617,0xCA4737},{0xCA4737,0xCA4745,0xCA4865},{0xCA4865,0xCA4873,0xCA4993},
    {0xCA4993,0xCA499F,0xCA4A9F},{0xCA4A9F,0xCA4AB1,0xCA4BB1},{0xCA4BB1,0xCA4BC3,0xCA4CC3}};
  static constexpr DynamicPoseSpec kiddyDriver[9]={
    {0xCA08E1,0xCA08EB,0xCA096B},{0xCA096B,0xCA0975,0xCA09F5},{0xCA09F5,0xCA09FF,0xCA0A7F},
    {0xCA0A7F,0xCA0A89,0xCA0B09},{0xCA0B09,0xCA0B17,0xCA0B77},{0xCA0B77,0xCA0B81,0xCA0C01},
    {0xCA0C01,0xCA0C0B,0xCA0C8B},{0xCA0C8B,0xCA0C99,0xCA0CF9},{0xCA0CF9,0xCA0D07,0xCA0D67}};
  static constexpr DynamicPoseSpec dixiePassenger[9]={
    {0xCA185B,0xCA1867,0xCA18A7},{0xCA18A7,0xCA18B3,0xCA18F3},{0xCA18F3,0xCA18FF,0xCA193F},
    {0xCA193F,0xCA194B,0xCA198B},{0xCA198B,0xCA1999,0xCA19F9},{0xCA19F9,0xCA1A05,0xCA1A45},
    {0xCA1A45,0xCA1A51,0xCA1A91},{0xCA1A91,0xCA1A9D,0xCA1ADD},{0xCA1ADD,0xCA1AE9,0xCA1B29}};
  const auto boatPal=loadSpritePalette(rom,0xFD4895,0xFD48B3);const auto kongPal=loadSpritePalette(rom,0xFD4387,0xFD43A5);
  frames.clear();frames.reserve(9);
  for(int i=0;i<9;++i){
    RomSpriteFrame f;f.width=40;f.height=40;f.anchorX=20;f.anchorY=20;f.pixels.assign(1600,0);
    std::vector<DynamicPiece> p;
    if(!decodeDynamicPose(rom,boat[i],boatPal,p))return false;
    blitPieces(p,f);
    if(!decodeDynamicPose(rom,kiddyDriver[i],kongPal,p))return false;
    blitPieces(p,f);
    if(!decodeDynamicPose(rom,dixiePassenger[i],kongPal,p))return false;
    blitPieces(p,f);
    frames.push_back(std::move(f));
  }
  return true;
}
}

bool buildDixieMapWalkFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec dixieSide[8]={
    {0xC9FB57,0xC9FB61,0xC9FBE1},{0xC9FBE1,0xC9FBEB,0xC9FC6B},
    {0xC9FC6B,0xC9FC75,0xC9FCF5},{0xC9FCF5,0xC9FCFF,0xC9FD7F},
    {0xC9FD7F,0xC9FD89,0xC9FE09},{0xC9FE09,0xC9FE13,0xC9FE93},
    {0xC9FE93,0xC9FE9D,0xC9FF1D},{0xC9FF1D,0xC9FF27,0xC9FFA7}};
  const auto pal=loadSpritePalette(rom,0xFD4387,0xFD43A5);
  frames.clear();frames.reserve(8);
  for(const auto& spec:dixieSide){
    RomSpriteFrame f;f.width=40;f.height=40;f.anchorX=20;f.anchorY=20;f.pixels.assign(1600,0);
    std::vector<DynamicPiece> pieces;
    if(!decodeDynamicPose(rom,spec,pal,pieces))return false;
    blitPieces(pieces,f);frames.push_back(std::move(f));
  }
  return true;
}


bool RomImage::load(const std::string& path){
  data_.clear();info_=RomInfo{};
  std::ifstream f(path,std::ios::binary);if(!f)return false;
  f.seekg(0,std::ios::end);const auto len=f.tellg();if(len<=0)return false;f.seekg(0,std::ios::beg);
  data_.resize((size_t)len);f.read((char*)data_.data(),len);if(!f){data_.clear();return false;}
  info_.path=path;info_.size=data_.size();info_.crc32=crc32(data_.data(),data_.size());
  if(data_.size()>=0xffd5){
    std::string t((const char*)data_.data()+0xffc0,21);while(!t.empty()&&(t.back()==' '||t.back()=='\0'))t.pop_back();info_.title=t;
    const uint8_t map=data_[0xffd5];info_.valid=(data_.size()==4194304u&&t.find("DONKEY KONG COUNTRY 3")!=std::string::npos&&(map==0x31||map==0x30));
  }
  return true;
}
bool RomImage::loadFirstAvailable(const std::vector<std::string>& paths){for(const auto& p:paths)if(load(p)&&info_.valid)return true;return false;}
bool RomImage::range(size_t begin,size_t end,std::vector<uint8_t>& out) const{if(begin>end||end>data_.size())return false;out.assign(data_.begin()+(ptrdiff_t)begin,data_.begin()+(ptrdiff_t)end);return true;}

bool dkc3BigDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed){
  out.clear();if(!data||size<0x27)return false;NibbleReader r{data,size,0x27,true};
  auto relay=[&](size_t dist)->bool{if(dist==0||dist>out.size())return false;out.push_back(out[out.size()-dist]);return true;};
  for(;;){
    int c=r.nib();if(c<0)return false;
    if(c==0){int k=r.nib();if(k<0)return false;if(k==0)break;while(k--){int v=r.byte();if(v<0)return false;out.push_back((uint8_t)v);}}
    else if(c==1||c==2){int k=(c==1)?1:2;while(k--){int v=r.byte();if(v<0)return false;out.push_back((uint8_t)v);}}
    else if(c==3){int k=r.nib(),v=r.byte();if(k<0||v<0)return false;k+=3;out.insert(out.end(),(size_t)k,(uint8_t)v);}
    else if(c==4||c==5){int k=r.nib();if(k<0)return false;k+=3;out.insert(out.end(),(size_t)k,data[1+(c&1)]);}
    else if(c==6){out.push_back(data[5]);out.push_back(data[6]);}
    else if(c==7||c==8){out.push_back(data[3+((c^1)&1)]);}
    else if(c==9){int d=r.nib();if(d<0)return false;d+=2;if(!relay((size_t)d)||!relay((size_t)d))return false;}
    else if(c==10){int k=r.nib(),d=r.byte();if(k<0||d<0)return false;k+=3;d+=k;while(k--)if(!relay((size_t)d))return false;}
    else if(c==11){int k=r.nib(),a=r.byte(),lo=r.nib();if(k<0||a<0||lo<0)return false;k+=3;size_t d=(size_t)(((a<<4)|lo)+0x103);while(k--)if(!relay(d))return false;}
    else if(c==12){int k=r.nib(),a=r.byte(),lo=r.byte();if(k<0||a<0||lo<0)return false;k+=3;size_t d=(size_t)((a<<8)|lo);while(k--)if(!relay(d))return false;}
    else if(c==13){if(!relay(1))return false;}
    else if(c==14){if(!relay(2)||!relay(2))return false;}
    else if(c==15){int a=r.nib();if(a<0)return false;a=(a<<1)+7;if((size_t)a+1>=size)return false;out.push_back(data[a]);out.push_back(data[a+1]);}
    if(out.size()>65536u)return false;
  }
  if(consumed)*consumed=r.pos+(r.high?0u:1u);
  return true;
}

bool dkc3SmallDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed){
  out.clear();if(!data||size<3)return false;const int flags=data[0]&7;const size_t words=(size_t)data[1]|((size_t)data[2]<<8);if(words>32768u)return false;
  std::vector<uint16_t> w(words,0);size_t bp=3;int bit=0;
  auto bits=[&](int count,int& result)->bool{unsigned v=0;while(count--){if(bp>=size)return false;v=(v<<1)|((data[bp]>>(7-bit))&1u);if(++bit==8){bit=0;++bp;}}result=(int)v;return true;};
  auto sub=[&](int mode)->bool{size_t a=0;int vs=1,cs=6,shift=13+mode;if(mode==3){vs=3;cs=4;shift=10;}for(;;){int loop=0,v=0,k=0;if(!bits(1,loop)||!bits(vs,v))return false;v<<=shift;if(loop){if(!bits(cs,k))return false;}else k=1;if(k==0)break;while(k--){if(a>=w.size())return false;w[a++]|=(uint16_t)v;}}return true;};
  for(int i=0;i<3;++i)if((flags&(1<<i))&&!sub(i))return false;
  if(!sub(3))return false;
  size_t a=0;for(;;){int mode=0,v=0,k=0;if(!bits(2,mode)||!bits(10,v))return false;if(mode==0)k=1;else if(mode==1){if(!bits(6,k))return false;if(k==0)break;}else{if(!bits(4,k)||k==0)return false;}while(k--){if(a>=w.size())return false;w[a++]|=(uint16_t)v;if(mode==2)v=(v+1)&0x3ff;else if(mode==3)v=(v-1)&0x3ff;}}
  out.resize(words*2);for(size_t i=0;i<words;++i){out[i*2]=(uint8_t)w[i];out[i*2+1]=(uint8_t)(w[i]>>8);}if(consumed)*consumed=bp+(bit?1u:0u);return true;
}

bool renderSnesLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX,int dstY,std::vector<uint8_t>* opaqueMask){
  if(layer.widthTiles<=0||layer.heightTiles<=0||layer.palette.size()<2||outW<=0||outH<=0||(layer.bpp!=2&&layer.bpp!=4))return false;
  const size_t needEntries=(size_t)((layer.widthTiles+31)/32)*(size_t)((layer.heightTiles+31)/32)*1024u;
  if(layer.snesScreenBlocks&&layer.tilemap.size()/2<needEntries)return false;
  if(!layer.snesScreenBlocks&&layer.tilemap.size()/2<(size_t)layer.widthTiles*(size_t)layer.heightTiles)return false;
  if(out.size()!=(size_t)outW*(size_t)outH)out.assign((size_t)outW*(size_t)outH,0);
  if(opaqueMask&&opaqueMask->size()!=out.size())opaqueMask->assign(out.size(),0);
  std::array<uint32_t,128> pal{};const size_t pc=std::min<size_t>(128,layer.palette.size()/2);for(size_t i=0;i<pc;++i)pal[i]=bgr555((uint16_t)(layer.palette[i*2]|(layer.palette[i*2+1]<<8)));
  const size_t tileBytes=layer.bpp==4?32u:16u;
  for(int ty=0;ty<layer.heightTiles;++ty)for(int tx=0;tx<layer.widthTiles;++tx){
    const size_t ei=tilemapEntryIndex(layer,tx,ty);const uint16_t e=(uint16_t)(layer.tilemap[ei*2]|(layer.tilemap[ei*2+1]<<8));const int tile=e&0x3ff;const int p=(e>>10)&7;const bool xf=(e&0x4000)!=0,yf=(e&0x8000)!=0;const size_t off=(size_t)tile*tileBytes;if(off+tileBytes>layer.gfx4bpp.size())continue;
    for(int py=0;py<8;++py){
      const int sy=yf?7-py:py;const uint8_t p0=layer.gfx4bpp[off+sy*2],p1=layer.gfx4bpp[off+sy*2+1];const uint8_t p2=layer.bpp==4?layer.gfx4bpp[off+16+sy*2]:0,p3=layer.bpp==4?layer.gfx4bpp[off+16+sy*2+1]:0;
      for(int px=0;px<8;++px){
        const int sx=xf?7-px:px,bb=7-sx;const int ci=((p0>>bb)&1)|(((p1>>bb)&1)<<1)|(layer.bpp==4?(((p2>>bb)&1)<<2)|(((p3>>bb)&1)<<3):0);if(layer.transparentZero&&ci==0)continue;
        const int dx=dstX+tx*8+px,dy=dstY+ty*8+py;if(dx<0||dy<0||dx>=outW||dy>=outH)continue;const int pi=p*(layer.bpp==4?16:4)+ci;if(pi<(int)pc){const size_t oi=(size_t)dy*(size_t)outW+(size_t)dx;out[oi]=pal[(size_t)pi];if(opaqueMask)(*opaqueMask)[oi]=1;}
      }
    }
  }
  return true;
}

bool renderSnes4bppLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX,int dstY){RomLayer copy=layer;copy.bpp=4;return renderSnesLayer(copy,out,outW,outH,dstX,dstY,nullptr);}

bool RomFrontendVisuals::load(const std::string& romPath){
  valid_=false;title_.clear();fileSelect_.clear();RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  auto slice=[&](size_t a,size_t b,std::vector<uint8_t>& v){return rom.range(a,b,v);};
  std::vector<uint8_t> cg1,cg2,ct1,ct2,pal,g1,g2,t1,t2;
  if(!slice(0x0CFE3D,0x0D3DD2,cg1)||!slice(0x29342E,0x2945BC,cg2)||!slice(0x287581,0x2877CC,ct1)||!slice(0x29339E,0x29342E,ct2)||!slice(0x3D7701,0x3D7801,pal))return false;
  if(!dkc3BigDataDecompress(cg1.data(),cg1.size(),g1)||!dkc3BigDataDecompress(cg2.data(),cg2.size(),g2)||!dkc3SmallDataDecompress(ct1.data(),ct1.size(),t1)||!dkc3SmallDataDecompress(ct2.data(),ct2.size(),t2))return false;
  title_.assign(256u*224u,0);RomLayer l1{32,28,std::move(g1),std::move(t1),pal,false,4,false};if(!renderSnesLayer(l1,title_,256,224))return false;
  RomLayer l2{32,12,std::move(g2),std::move(t2),pal,true,4,false};if(!renderSnesLayer(l2,title_,256,224))return false;
  std::vector<uint8_t> fcg,ftm,fg,fp;
  if(!slice(0x13FE2A,0x141E8B,fcg)||!slice(0x2A0488,0x2A0694,ftm)||!slice(0x3D8641,0x3D8741,fp))return false;
  if(!dkc3BigDataDecompress(fcg.data(),fcg.size(),fg)||!dkc3SmallDataDecompress(ftm.data(),ftm.size(),t1))return false;
  fileSelect_.assign(256u*224u,0);if(t1.size()<32u*30u*2u)return false;t1.resize(32u*30u*2u);RomLayer fs{32,30,std::move(fg),std::move(t1),std::move(fp),false,4,false};if(!renderSnesLayer(fs,fileSelect_,256,224))return false;
  valid_=true;return true;
}
std::string RomFrontendVisuals::status() const{std::ostringstream ss;if(!valid_){ss<<"ROM NAO ENCONTRADA/INVALIDA";return ss.str();}ss<<info_.title<<" CRC32="<<std::hex<<info_.crc32;return ss.str();}

bool RomLakesideLimboVisuals::load(const std::string& romPath){
  valid_=false;pixels_.clear();foregroundMask_.clear();placements_.clear();placementData_.clear();
  RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  std::vector<uint8_t> packedLevel,packedMap32,packedFg,packedBg,packedBgMap,palette;
  std::vector<uint8_t> level,map32,fg,bg,bgMap;
  if(!rom.range(hiromToPc(0xE4890B),hiromToPc(0xE4AEF3),packedLevel) ||
     !rom.range(hiromToPc(0xE4AEF3),hiromToPc(0xE4D0AF),packedMap32) ||
     !rom.range(hiromToPc(0xE4D25F),hiromToPc(0xE5260F),packedFg) ||
     !rom.range(hiromToPc(0xE8861B),hiromToPc(0xE8A412),packedBg) ||
     !rom.range(hiromToPc(0xE88388),hiromToPc(0xE8861B),packedBgMap) ||
     !rom.range(hiromToPc(0xFD5601),hiromToPc(0xFD5701),palette) ||
     !rom.range(hiromToPc(0xFE05B2),hiromToPc(0xFE072C),placementData_))return false;
  if(!dkc3BigDataDecompress(packedLevel.data(),packedLevel.size(),level) ||
     !dkc3BigDataDecompress(packedMap32.data(),packedMap32.size(),map32) ||
     !dkc3BigDataDecompress(packedFg.data(),packedFg.size(),fg) ||
     !dkc3BigDataDecompress(packedBg.data(),packedBg.size(),bg) ||
     !dkc3SmallDataDecompress(packedBgMap.data(),packedBgMap.size(),bgMap))return false;

  constexpr int kColumns=195;
  constexpr int kRows=16;
  constexpr int kSourceCropY=64;
  if(level.size()<(size_t)kColumns*kRows*2u || map32.size()<32u || fg.size()<32u ||
     bgMap.size()<32u*18u*2u || palette.size()<256u)return false;

  std::vector<uint32_t> background(256u*144u,0);
  RomLayer bgLayer{32,18,std::move(bg),std::move(bgMap),palette,false,4,false};
  if(!renderSnesLayer(bgLayer,background,256,144))return false;

  pixels_.resize((size_t)width_*(size_t)height_);
  foregroundMask_.assign(pixels_.size(),0);
  for(int y=0;y<height_;++y){
    for(int x=0;x<width_;++x){
      pixels_[(size_t)y*(size_t)width_+(size_t)x]=background[(size_t)(y%144)*256u+(size_t)(x&255)];
    }
  }

  std::array<uint32_t,128> pal{};
  for(size_t i=0;i<pal.size();++i)pal[i]=bgr555((uint16_t)(palette[i*2]|(palette[i*2+1]<<8)));
  auto drawTile=[&](uint16_t entry,int dx,int rawY){
    const int tile=entry&0x03ff;
    const int paletteIndex=(entry>>10)&7;
    const bool xflip=(entry&0x4000)!=0;
    const bool yflip=(entry&0x8000)!=0;
    const size_t tileOff=(size_t)tile*32u;
    if(tileOff+32u>fg.size())return;
    for(int py=0;py<8;++py){
      const int sy=yflip?7-py:py;
      const uint8_t p0=fg[tileOff+(size_t)sy*2u];
      const uint8_t p1=fg[tileOff+(size_t)sy*2u+1u];
      const uint8_t p2=fg[tileOff+16u+(size_t)sy*2u];
      const uint8_t p3=fg[tileOff+16u+(size_t)sy*2u+1u];
      const int outY=rawY+py-kSourceCropY;
      if(outY<0||outY>=height_)continue;
      for(int px=0;px<8;++px){
        const int sx=xflip?7-px:px;
        const int bit=7-sx;
        const int ci=((p0>>bit)&1)|(((p1>>bit)&1)<<1)|(((p2>>bit)&1)<<2)|(((p3>>bit)&1)<<3);
        if(ci==0)continue;
        const int outX=dx+px;
        if(outX<0||outX>=width_)continue;
        const int pi=paletteIndex*16+ci;
        const size_t oi=(size_t)outY*(size_t)width_+(size_t)outX;
        pixels_[oi]=pal[(size_t)pi];
        foregroundMask_[oi]=1;
      }
    }
  };

  for(int mx=0;mx<kColumns;++mx){
    for(int my=0;my<kRows;++my){
      const size_t mapOff=((size_t)mx*(size_t)kRows+(size_t)my)*2u;
      const uint16_t metatile=(uint16_t)(level[mapOff]|((uint16_t)level[mapOff+1u]<<8));
      const uint16_t flips=(uint16_t)(metatile&0xc000u);
      const uint16_t scaled=(uint16_t)((uint16_t)(metatile<<5)+((metatile&0x0800u)?1u:0u));
      for(int sy=0;sy<4;++sy){
        for(int sx=0;sx<4;++sx){
          const int ssx=(flips&0x4000u)?3-sx:sx;
          const int ssy=(flips&0x8000u)?3-sy:sy;
          const uint16_t defOff=(uint16_t)(scaled+(uint16_t)(ssy*8+ssx*2));
          if((size_t)defOff+1u>=map32.size())continue;
          const uint16_t entry=(uint16_t)((map32[(size_t)defOff]|((uint16_t)map32[(size_t)defOff+1u]<<8))^flips);
          drawTile(entry,mx*32+sx*8,my*32+sy*8);
        }
      }
    }
  }

  for(size_t off=0;off+1u<placementData_.size();off+=8u){
    const uint16_t parameter=(uint16_t)(placementData_[off]|((uint16_t)placementData_[off+1u]<<8));
    if(parameter==0)break;
    if(off+7u>=placementData_.size())return false;
    RomLevelPlacement p;
    p.parameter=parameter;
    p.x=(uint16_t)(placementData_[off+2u]|((uint16_t)placementData_[off+3u]<<8));
    p.y=(uint16_t)(placementData_[off+4u]|((uint16_t)placementData_[off+5u]<<8));
    p.type=(uint16_t)(placementData_[off+6u]|((uint16_t)placementData_[off+7u]<<8));
    placements_.push_back(p);
  }
  if(placements_.size()!=47u)return false;
  valid_=true;return true;
}

bool RomLakeOrangatangaVisuals::load(const std::string& romPath){
  valid_=false;map_.clear();collision_.clear();dixieWalkFrames_.clear();
  RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  std::vector<uint8_t> packedGfx,packedMap,gfx,tilemap,palette;
  if(!rom.range(hiromToPc(0xCFFF7E),hiromToPc(0xD04F61),packedGfx))return false;
  if(!rom.range(hiromToPc(0xE86F2B),hiromToPc(0xE871D7),packedMap))return false;
  if(!rom.range(hiromToPc(0xFD7D41),hiromToPc(0xFD7E41),palette))return false;
  if(!rom.range(hiromToPc(0xE926FB),hiromToPc(0xE92796),collision_))return false;
  if(!dkc3BigDataDecompress(packedGfx.data(),packedGfx.size(),gfx))return false;
  if(!dkc3SmallDataDecompress(packedMap.data(),packedMap.size(),tilemap))return false;
  if(tilemap.size()!=32u*28u*2u)return false;
  map_.assign(256u*224u,0);
  RomLayer layer{32,28,std::move(gfx),std::move(tilemap),std::move(palette),false,4,false};
  if(!renderSnesLayer(layer,map_,256,224))return false;
  if(!buildDixieMapWalkFrames(rom,dixieWalkFrames_))return false;
  valid_=true;return true;
}

bool RomWorldMapVisuals::load(const std::string& romPath){
  valid_=false;map_.clear();landMask_.clear();boatFrames_.clear();RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  auto dec=[&](size_t a,size_t b,std::vector<uint8_t>& out)->bool{std::vector<uint8_t> in;if(!rom.range(a,b,in))return false;return dkc3BigDataDecompress(in.data(),in.size(),out);};
  std::vector<uint8_t> pal;if(!rom.range(0x3D7421,0x3D7521,pal))return false;
  std::vector<uint8_t> wg,wt,l3g,l3t,l1g,l1t;
  if(!dec(0x2B0B39,0x2B12E2,wg)||!dec(0x2B081C,0x2B0B39,wt)||!dec(0x321DA4,0x32275C,l3g)||!dec(0x3215A9,0x321DA4,l3t)||!dec(0x350000,0x35702E,l1g)||!dec(0x320000,0x3215A9,l1t))return false;
  std::vector<uint32_t> water(256u*256u,0);RomLayer waterLayer{32,32,std::move(wg),std::move(wt),pal,false,4,false};if(!renderSnesLayer(waterLayer,water,256,256))return false;
  map_.assign((size_t)width_*(size_t)height_,0);for(int y=0;y<height_;++y)for(int x=0;x<width_;++x)map_[(size_t)y*(size_t)width_+(size_t)x]=water[(size_t)(y&255)*256u+(size_t)(x&255)];
  RomLayer shore{64,64,std::move(l3g),std::move(l3t),pal,true,2,true};if(!renderSnesLayer(shore,map_,width_,height_))return false;
  RomLayer land{64,64,std::move(l1g),std::move(l1t),pal,true,4,true};landMask_.assign(map_.size(),0);if(!renderSnesLayer(land,map_,width_,height_,0,0,&landMask_))return false;
  if(!buildBoatFrames(rom,boatFrames_))return false;
  valid_=true;return true;
}

bool RomWorldMapVisuals::landAt(int x,int y) const{if(!valid_||x<0||y<0||x>=width_||y>=height_)return true;return landMask_[(size_t)y*(size_t)width_+(size_t)x]!=0;}
bool RomWorldMapVisuals::boatBlocked(float x,float y,int halfW,int halfH) const{
  if(!valid_)return false;
  const int cx=(int)std::lround(x),cy=(int)std::lround(y);
  for(int sy=-halfH;sy<=halfH;sy+=3)for(int sx=-halfW;sx<=halfW;sx+=3)if(landAt(cx+sx,cy+sy))return true;
  return landAt(cx-halfW,cy-halfH)||landAt(cx+halfW,cy-halfH)||landAt(cx-halfW,cy+halfH)||landAt(cx+halfW,cy+halfH);
}

}
