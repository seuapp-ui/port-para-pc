#include "WorldMap.h"
#include "Hud.h"
#include <algorithm>
#include <cmath>

namespace dkc3 {
namespace {
constexpr float kFadeInSeconds=0.42f;
constexpr float kLaunchSeconds=0.54f;
constexpr float kLakeGatewayX=445.0f;
constexpr float kLakeGatewayY=420.0f;
constexpr float kLakeGatewayRadius=34.0f;

void label(uint32_t* dst,int w,int h,int x,int y,const std::string& s,uint32_t c){hudDrawText(dst,w,h,x,y,s,c,1);}
void drawFallbackWater(uint32_t*dst,int w,int h){hudFillRect(dst,w,h,0,0,w,h,0x0a5274u,255);for(int y=20;y<h;y+=12)hudFillRect(dst,w,h,0,y,w,4,0x0d6587u,255);}
void blitFrame(uint32_t* dst,int w,int h,const RomSpriteFrame& f,int cx,int cy,bool flip){
  for(int sy=0;sy<f.height;++sy)for(int sx=0;sx<f.width;++sx){
    const int rx=flip?(f.width-1-sx):sx;const uint32_t c=f.pixels[(size_t)sy*(size_t)f.width+(size_t)rx];
    if((c>>24)==0)continue;
    const int dx=cx-f.anchorX+sx,dy=cy-f.anchorY+sy;
    if(dx>=0&&dy>=0&&dx<w&&dy<h)dst[(size_t)dy*(size_t)w+(size_t)dx]=c&0x00ffffffu;
  }
}
}

unsigned WorldMap::stageBit(const std::string& id){
  if(id=="lakeside-limbo")return 1u<<0;
  if(id=="doorstop")return 1u<<1;
  if(id=="tidal-trouble")return 1u<<2;
  if(id=="skiddas-row")return 1u<<3;
  if(id=="murky-mill")return 1u<<4;
  if(id=="belchas-barn")return 1u<<5;
  return 0u;
}

bool WorldMap::init(const WorldMapState& state,const std::string& romPath){
  // Coordinates are calibrated against the 256x224 Lake Orangatanga layer decoded
  // from the supplied ROM. The original E9:26FB collision/route stream is preserved
  // by RomLakeOrangatangaVisuals and will replace this calibrated node graph once its
  // command semantics are fully decoded.
  stages_={
    {"lakeside-limbo","LAKESIDE LIMBO",27,132,stageBit("lakeside-limbo"),0x0025},
    {"doorstop","DOORSTOP DASH",74,158,stageBit("doorstop"),0x0028},
    {"tidal-trouble","TIDAL TROUBLE",123,117,stageBit("tidal-trouble"),0x0027},
    {"skiddas-row","SKIDDA'S ROW",173,94,stageBit("skiddas-row"),0x002B},
    {"murky-mill","MURKY MILL",193,146,stageBit("murky-mill"),0x002A},
    {"belchas-barn","BELCHA'S BARN",220,70,stageBit("belchas-barn"),0x001D}};
  pendingLaunch_.clear();launchTarget_.clear();toast_.clear();toastTimer_=0;animTime_=0;transitionTimer_=0;
  prev_=WorldMapInput{};boatFacing_=0;boatMoving_=false;lakeFacingLeft_=false;transition_=Transition::FadeIn;currentLevel_="lakeside-limbo";
  const bool mainOk=romMap_.load(romPath);const bool lakeOk=lakeMap_.load(romPath);setState(state);return mainOk&&lakeOk;
}

void WorldMap::setState(const WorldMapState& s){
  state_=s;state_.unlockedMask|=stageBit("lakeside-limbo");
  if(state_.area!=(int)WorldArea::LakeOrangatanga)state_.area=(int)WorldArea::NorthernKremisphere;
  state_.lakeNode=std::clamp(state_.lakeNode,0,std::max(0,(int)stages_.size()-1));
  const float maxX=romMap_.valid()?(float)(romMap_.width()-9):503.0f;const float maxY=romMap_.valid()?(float)(romMap_.height()-9):503.0f;
  state_.boatX=std::clamp(state_.boatX,8.0f,maxX);state_.boatY=std::clamp(state_.boatY,8.0f,maxY);
  if(romMap_.valid()&&romMap_.boatBlocked(state_.boatX,state_.boatY)){state_.boatX=348.0f;state_.boatY=420.0f;}
  if(area()==WorldArea::LakeOrangatanga)selectLakeNode(state_.lakeNode);
}

void WorldMap::setCurrentLevel(const std::string& level){
  if(level.empty())return;
  currentLevel_=level;
  const int i=stageIndex(level);
  if(i>=0)state_.lakeNode=i;
}

bool WorldMap::blocked(float x,float y)const{return romMap_.valid()?romMap_.boatBlocked(x,y):false;}
const WorldMapStage* WorldMap::stageById(const std::string& id)const{for(const auto&s:stages_)if(s.id==id)return &s;return nullptr;}
int WorldMap::stageIndex(const std::string& id)const{for(size_t i=0;i<stages_.size();++i)if(stages_[i].id==id)return (int)i;return -1;}
std::string WorldMap::nearestStageId()const{return currentLevel_;}
std::string WorldMap::stageDisplayName(const std::string& id)const{const auto*s=stageById(id);return s?s->name:id;}

bool WorldMap::nearLakeGateway()const{
  const float dx=state_.boatX-kLakeGatewayX,dy=state_.boatY-kLakeGatewayY;
  return dx*dx+dy*dy<=kLakeGatewayRadius*kLakeGatewayRadius;
}

void WorldMap::selectLakeNode(int index){
  if(stages_.empty())return;
  state_.lakeNode=std::clamp(index,0,(int)stages_.size()-1);
  currentLevel_=stages_[(size_t)state_.lakeNode].id;
}

void WorldMap::enterLake(){
  state_.area=(int)WorldArea::LakeOrangatanga;int i=stageIndex(currentLevel_);if(i<0)i=0;selectLakeNode(i);
  transition_=Transition::FadeIn;transitionTimer_=0.0f;showToast("LAKE ORANGATANGA",1.4f);
}
void WorldMap::leaveLake(){state_.area=(int)WorldArea::NorthernKremisphere;transition_=Transition::FadeIn;transitionTimer_=0.0f;showToast("NORTHERN KREMISPHERE",1.2f);}

float WorldMap::transitionProgress()const{
  if(transition_==Transition::Idle)return 1.0f;
  const float d=transition_==Transition::FadeIn?kFadeInSeconds:kLaunchSeconds;
  return std::clamp(transitionTimer_/d,0.0f,1.0f);
}

void WorldMap::step(const WorldMapInput& in,float dt){
  dt=std::clamp(dt,0.0f,0.1f);animTime_+=dt;if(toastTimer_>0.0f)toastTimer_=std::max(0.0f,toastTimer_-dt);
  if(transition_!=Transition::Idle){
    transitionTimer_+=dt;boatMoving_=false;
    if(transition_==Transition::FadeIn&&transitionTimer_>=kFadeInSeconds){transition_=Transition::Idle;transitionTimer_=0.0f;}
    else if(transition_==Transition::Launching&&transitionTimer_>=kLaunchSeconds&&pendingLaunch_.empty()&&!launchTarget_.empty()){pendingLaunch_=launchTarget_;launchTarget_.clear();}
    prev_=in;return;
  }

  const bool confirm=in.confirm&&!prev_.confirm,cancel=in.cancel&&!prev_.cancel;
  const bool left=in.left&&!prev_.left,right=in.right&&!prev_.right,up=in.up&&!prev_.up,down=in.down&&!prev_.down;

  if(area()==WorldArea::LakeOrangatanga){
    boatMoving_=false;
    if(cancel){leaveLake();prev_=in;return;}
    int target=state_.lakeNode;
    if(left||up){target=std::max(0,target-1);lakeFacingLeft_=true;}
    if(right||down){target=std::min((int)stages_.size()-1,target+1);lakeFacingLeft_=false;}
    if(target!=state_.lakeNode){
      const unsigned bit=stages_[(size_t)target].bit;
      if((state_.unlockedMask&bit)!=0u)selectLakeNode(target);else showToast("CAMINHO AINDA BLOQUEADO");
    }
    if(confirm&&pendingLaunch_.empty()){
      const auto& st=stages_[(size_t)state_.lakeNode];
      if((state_.unlockedMask&st.bit)==0u)showToast("CAMINHO AINDA BLOQUEADO");
      else if((runtimeAvailableMask_&st.bit)==0u)showToast("FASE AINDA NAO PORTADA");
      else{launchTarget_=st.id;transition_=Transition::Launching;transitionTimer_=0.0f;showToast("ENTRANDO EM "+st.name,0.8f);}
    }
    prev_=in;return;
  }

  float dx=(in.right?1.0f:0.0f)-(in.left?1.0f:0.0f),dy=(in.down?1.0f:0.0f)-(in.up?1.0f:0.0f);boatMoving_=dx!=0.0f||dy!=0.0f;
  if(boatMoving_){
    const int sx=dx>0?1:(dx<0?-1:0),sy=dy>0?1:(dy<0?-1:0);
    if(sy>0&&sx==0)boatFacing_=0;else if(sy>0&&sx>0)boatFacing_=1;else if(sy==0&&sx>0)boatFacing_=2;else if(sy<0&&sx>0)boatFacing_=3;else if(sy<0&&sx==0)boatFacing_=4;else if(sy<0&&sx<0)boatFacing_=5;else if(sy==0&&sx<0)boatFacing_=6;else boatFacing_=7;
    const float len=std::sqrt(dx*dx+dy*dy);dx/=len;dy/=len;const float sp=72.0f;
    const float maxX=romMap_.valid()?(float)(romMap_.width()-9):503.0f,maxY=romMap_.valid()?(float)(romMap_.height()-9):503.0f;
    const float nx=std::clamp(state_.boatX+dx*sp*dt,8.0f,maxX);if(!blocked(nx,state_.boatY))state_.boatX=nx;
    const float ny=std::clamp(state_.boatY+dy*sp*dt,8.0f,maxY);if(!blocked(state_.boatX,ny))state_.boatY=ny;
  }
  if(confirm){if(nearLakeGateway())enterLake();else showToast("NAVEGUE ATE LAKE ORANGATANGA");}
  prev_=in;
}

bool WorldMap::takeLaunchRequest(std::string& level){if(pendingLaunch_.empty())return false;level=pendingLaunch_;pendingLaunch_.clear();return true;}

void WorldMap::completeStage(const std::string& currentLevel,const std::string& nextLevel){
  const int ci=stageIndex(currentLevel),ni=stageIndex(nextLevel);const unsigned cur=stageBit(currentLevel),next=stageBit(nextLevel);
  const bool forward=ci>=0&&ni==ci+1;
  if(forward&&cur)state_.completedMask|=cur;
  if(forward&&next)state_.unlockedMask|=next;
  if(ni>=0){state_.area=(int)WorldArea::LakeOrangatanga;selectLakeNode(ni);}else if(!nextLevel.empty())currentLevel_=nextLevel;
  transition_=Transition::FadeIn;transitionTimer_=0.0f;launchTarget_.clear();pendingLaunch_.clear();showToast(forward&&next?"PROGRESSO SALVO":"VOLTOU AO MAPA",1.6f);
}

int WorldMap::boatFrameIndex()const{static constexpr int map[8]={0,2,4,6,8,6,4,2};return map[std::clamp(boatFacing_,0,7)];}
bool WorldMap::boatFlipX()const{return boatFacing_>=5||boatFacing_==7;}

void WorldMap::renderMain(uint32_t*dst,int w,int h)const{
  if(romMap_.valid()&&romMap_.mapPixels().size()==(size_t)romMap_.width()*(size_t)romMap_.height()){
    const int camX=std::clamp((int)std::lround(state_.boatX)-w/2,0,std::max(0,romMap_.width()-w));const int camY=std::clamp((int)std::lround(state_.boatY)-h/2,0,std::max(0,romMap_.height()-h));
    const auto& src=romMap_.mapPixels();for(int y=0;y<h;++y)for(int x=0;x<w;++x)dst[(size_t)y*(size_t)w+(size_t)x]=src[(size_t)(camY+y)*(size_t)romMap_.width()+(size_t)(camX+x)];
    const auto& frames=romMap_.boatFrames();if(!frames.empty()){
      const auto& f=frames[(size_t)std::clamp(boatFrameIndex(),0,(int)frames.size()-1)];const int cx=(int)std::lround(state_.boatX)-camX,cy=(int)std::lround(state_.boatY)-camY;blitFrame(dst,w,h,f,cx,cy,boatFlipX());
    }
  }else drawFallbackWater(dst,w,h);
  hudFillRect(dst,w,h,0,0,w,18,0x02080du,185);label(dst,w,h,7,5,"NORTHERN KREMISPHERE - ROM",0xffffe9a0u);
  hudFillRect(dst,w,h,4,h-31,w-8,27,0x02080du,195);
  label(dst,w,h,9,h-26,nearLakeGateway()?"LAKE ORANGATANGA - ENTER":"BARCO - PROCURE LAKE ORANGATANGA",0xffffffffu);
  label(dst,w,h,9,h-14,"ENTER/Z ENTRAR   SETAS/WASD BARCO",0xffd2e5ecu);
}

void WorldMap::renderLake(uint32_t*dst,int w,int h)const{
  if(lakeMap_.valid()&&lakeMap_.mapPixels().size()==256u*224u&&w==256&&h==224)std::copy(lakeMap_.mapPixels().begin(),lakeMap_.mapPixels().end(),dst);
  else{hudFillRect(dst,w,h,0,0,w,h,0x072740u,255);label(dst,w,h,60,96,"LAKE ORANGATANGA",0xffffffffu);}
  if(!stages_.empty()){
    const auto& st=stages_[(size_t)std::clamp(state_.lakeNode,0,(int)stages_.size()-1)];const auto& frames=lakeMap_.dixieWalkFrames();
    if(!frames.empty()){
      const int fi=((int)std::floor(animTime_*10.0f))%(int)frames.size();blitFrame(dst,w,h,frames[(size_t)fi],(int)std::lround(st.x),(int)std::lround(st.y),lakeFacingLeft_);
    }
    hudFillRect(dst,w,h,4,h-33,w-8,29,0x02080du,198);label(dst,w,h,9,h-28,st.name,0xffffffffu);
    std::string status=(state_.completedMask&st.bit)?"CONCLUIDA":((runtimeAvailableMask_&st.bit)?"ENTER/Z JOGAR":"AINDA NAO PORTADA");
    label(dst,w,h,9,h-16,status+"   X/B VOLTAR",(runtimeAvailableMask_&st.bit)?0xffd6f0d6u:0xffffd0a0u);
  }
}

void WorldMap::render(uint32_t*dst,int w,int h)const{
  if(!dst||w<=0||h<=0)return;
  if(area()==WorldArea::LakeOrangatanga)renderLake(dst,w,h);
  else renderMain(dst,w,h);
  if(toastTimer_>0.0f&&!toast_.empty()){const int tw=std::min(w-10,hudTextWidth(toast_)+12);hudFillRect(dst,w,h,(w-tw)/2,22,tw,15,0x000000u,205);label(dst,w,h,(w-tw)/2+6,25,toast_,0xffffffffu);}
  if(transition_==Transition::Launching){const int a=(int)std::lround(255.0f*transitionProgress());hudFillRect(dst,w,h,0,0,w,h,0x000000u,(uint8_t)std::clamp(a,0,255));}
  else if(transition_==Transition::FadeIn){const int a=(int)std::lround(255.0f*(1.0f-transitionProgress()));hudFillRect(dst,w,h,0,0,w,h,0x000000u,(uint8_t)std::clamp(a,0,255));}
}

}
