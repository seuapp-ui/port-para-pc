#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "RomData.h"

namespace dkc3 {

enum class WorldArea : int {
  NorthernKremisphere=0,
  LakeOrangatanga=1
};

struct WorldMapState {
  float boatX=348.0f;
  float boatY=420.0f;
  unsigned unlockedMask=1u;   // v0.27+: Lakeside, Doorstop, Tidal, Skidda, Murky, Belcha
  unsigned completedMask=0u;
  int area=(int)WorldArea::NorthernKremisphere;
  int lakeNode=0;
};

struct WorldMapInput {
  bool left=false,right=false,up=false,down=false;
  bool confirm=false,cancel=false;
};

struct WorldMapStage {
  std::string id;
  std::string name;
  float x=0,y=0;
  unsigned bit=0;
  uint16_t originalLevelId=0;
};

class WorldMap {
 public:
  bool init(const WorldMapState& state={},const std::string& romPath="");
  void setRuntimeAvailableMask(unsigned mask){runtimeAvailableMask_=mask;}
  unsigned runtimeAvailableMask()const{return runtimeAvailableMask_;}
  void setCurrentLevel(const std::string& level);
  const std::string& currentLevel()const{return currentLevel_;}
  bool romBacked()const{return romMap_.valid()&&lakeMap_.valid();}
  bool lakeRomBacked()const{return lakeMap_.valid();}
  WorldArea area()const{return state_.area==(int)WorldArea::LakeOrangatanga?WorldArea::LakeOrangatanga:WorldArea::NorthernKremisphere;}
  void step(const WorldMapInput& in,float dt);
  void render(uint32_t* dst,int w,int h)const;
  bool takeLaunchRequest(std::string& level);
  void completeStage(const std::string& currentLevel,const std::string& nextLevel);
  const WorldMapState& state()const{return state_;}
  void setState(const WorldMapState& s);
  const std::vector<WorldMapStage>& stages()const{return stages_;}
  std::string nearestStageId()const;
  std::string toast()const{return toast_;}
  float toastTime()const{return toastTimer_;}
  bool transitionActive()const{return transition_!=Transition::Idle;}
  float transitionProgress()const;
  static unsigned stageBit(const std::string& id);
 private:
  enum class Transition { FadeIn, Idle, Launching, AreaSwitch };
  const WorldMapStage* stageById(const std::string& id)const;
  int stageIndex(const std::string& id)const;
  bool blocked(float x,float y)const;
  bool nearLakeGateway()const;
  int boatFrameIndex()const;
  bool boatFlipX()const;
  std::string stageDisplayName(const std::string& id)const;
  void selectLakeNode(int index);
  void enterLake();
  void leaveLake();
  void renderMain(uint32_t* dst,int w,int h)const;
  void renderLake(uint32_t* dst,int w,int h)const;
  void showToast(const std::string& s,float seconds=1.4f){toast_=s;toastTimer_=seconds;}
  WorldMapState state_{};
  unsigned runtimeAvailableMask_=0;
  std::vector<WorldMapStage> stages_;
  RomWorldMapVisuals romMap_;
  RomLakeOrangatangaVisuals lakeMap_;
  std::string currentLevel_="lakeside-limbo";
  std::string pendingLaunch_;
  std::string launchTarget_;
  std::string toast_;
  float toastTimer_=0.0f,animTime_=0.0f,transitionTimer_=0.0f;
  int boatFacing_=0;
  bool boatMoving_=false;
  bool lakeFacingLeft_=false;
  Transition transition_=Transition::FadeIn;
  WorldMapInput prev_{};
};

}
