#include "Bmp.h"
#include <fstream>
#include <vector>
#include <cstring>
namespace dkc3 {
#pragma pack(push,1)
struct FH{uint16_t type;uint32_t size;uint16_t r1,r2;uint32_t off;};
struct IH{uint32_t size;int32_t w,h;uint16_t planes,bpp;uint32_t comp,sizeImage;int32_t xppm,yppm;uint32_t clrUsed,clrImportant;};
#pragma pack(pop)
bool loadBmp32(const std::string& path, Bitmap& out){
  std::ifstream f(path,std::ios::binary); if(!f) return false; FH fh{}; IH ih{}; f.read((char*)&fh,sizeof fh); f.read((char*)&ih,sizeof ih);
  if(!f||fh.type!=0x4d42||ih.bpp!=32||ih.comp!=0||ih.w<=0||ih.h==0) return false;
  out.w=ih.w; out.h=ih.h<0?-ih.h:ih.h; out.bgra.resize((size_t)out.w*out.h); f.seekg(fh.off);
  std::vector<uint32_t> row(out.w); bool top=ih.h<0;
  for(int y=0;y<out.h;y++){ f.read((char*)row.data(),out.w*4); if(!f)return false; int dy=top?y:(out.h-1-y); std::memcpy(out.bgra.data()+(size_t)dy*out.w,row.data(),out.w*4); }
  return true;
}
bool saveBmp32(const std::string& path,const uint32_t* px,int w,int h){
  if(!px||w<=0||h<=0)return false;
  std::ofstream f(path,std::ios::binary);if(!f)return false;
  FH fh{};IH ih{};fh.type=0x4d42;fh.off=sizeof(FH)+sizeof(IH);fh.size=fh.off+(uint32_t)w*h*4;
  ih.size=sizeof(IH);ih.w=w;ih.h=-h;ih.planes=1;ih.bpp=32;ih.comp=0;ih.sizeImage=(uint32_t)w*h*4;
  f.write((const char*)&fh,sizeof fh);f.write((const char*)&ih,sizeof ih);f.write((const char*)px,(std::streamsize)w*h*4);return bool(f);
}
}
