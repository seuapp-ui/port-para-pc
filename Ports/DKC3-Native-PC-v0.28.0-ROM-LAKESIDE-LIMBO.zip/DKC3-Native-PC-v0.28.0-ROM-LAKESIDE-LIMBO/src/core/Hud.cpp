#include "Hud.h"
#include <algorithm>
#include <cctype>
#include <cstring>
namespace dkc3 {
namespace {
struct Glyph { char c; const char* rows; };  // 7 linhas de 5 bits separadas por '/'
const Glyph kFont[] = {
 {'A',"01110/10001/10001/11111/10001/10001/10001"},{'B',"11110/10001/10001/11110/10001/10001/11110"},
 {'C',"01110/10001/10000/10000/10000/10001/01110"},{'D',"11110/10001/10001/10001/10001/10001/11110"},
 {'E',"11111/10000/10000/11110/10000/10000/11111"},{'F',"11111/10000/10000/11110/10000/10000/10000"},
 {'G',"01110/10001/10000/10111/10001/10001/01111"},{'H',"10001/10001/10001/11111/10001/10001/10001"},
 {'I',"01110/00100/00100/00100/00100/00100/01110"},{'J',"00111/00010/00010/00010/00010/10010/01100"},
 {'K',"10001/10010/10100/11000/10100/10010/10001"},{'L',"10000/10000/10000/10000/10000/10000/11111"},
 {'M',"10001/11011/10101/10101/10001/10001/10001"},{'N',"10001/11001/10101/10011/10001/10001/10001"},
 {'O',"01110/10001/10001/10001/10001/10001/01110"},{'P',"11110/10001/10001/11110/10000/10000/10000"},
 {'Q',"01110/10001/10001/10001/10101/10010/01101"},{'R',"11110/10001/10001/11110/10100/10010/10001"},
 {'S',"01111/10000/10000/01110/00001/00001/11110"},{'T',"11111/00100/00100/00100/00100/00100/00100"},
 {'U',"10001/10001/10001/10001/10001/10001/01110"},{'V',"10001/10001/10001/10001/10001/01010/00100"},
 {'W',"10001/10001/10001/10101/10101/11011/10001"},{'X',"10001/10001/01010/00100/01010/10001/10001"},
 {'Y',"10001/10001/01010/00100/00100/00100/00100"},{'Z',"11111/00001/00010/00100/01000/10000/11111"},
 {'0',"01110/10001/10011/10101/11001/10001/01110"},{'1',"00100/01100/00100/00100/00100/00100/01110"},
 {'2',"01110/10001/00001/00010/00100/01000/11111"},{'3',"11110/00001/00001/01110/00001/00001/11110"},
 {'4',"00010/00110/01010/10010/11111/00010/00010"},{'5',"11111/10000/11110/00001/00001/10001/01110"},
 {'6',"00110/01000/10000/11110/10001/10001/01110"},{'7',"11111/00001/00010/00100/01000/01000/01000"},
 {'8',"01110/10001/10001/01110/10001/10001/01110"},{'9',"01110/10001/10001/01111/00001/00010/01100"},
 {':',"00000/00100/00000/00000/00000/00100/00000"},{'.',"00000/00000/00000/00000/00000/00000/00100"},
 {'-',"00000/00000/00000/11111/00000/00000/00000"},{'!',"00100/00100/00100/00100/00100/00000/00100"},
 {'/',"00001/00010/00010/00100/01000/01000/10000"},{'?',"01110/10001/00001/00110/00100/00000/00100"},
 {',',"00000/00000/00000/00000/00100/00100/01000"},
 {'+',"00000/00100/00100/11111/00100/00100/00000"},{'%',"11001/11010/00010/00100/01000/01011/10011"},
 {' ',"00000/00000/00000/00000/00000/00000/00000"},
};
const Glyph* findGlyph(char c){for(const auto&g:kFont)if(g.c==c)return &g;return nullptr;}
inline void put(uint32_t*dst,int w,int h,int x,int y,uint32_t c){if((unsigned)x<(unsigned)w&&(unsigned)y<(unsigned)h)dst[(size_t)y*w+x]=c;}
}
std::string hudSanitize(const std::string& t){
  std::string o;o.reserve(t.size());
  for(size_t i=0;i<t.size();++i){
    unsigned char c=(unsigned char)t[i];
    if(c>=0xC3&&i+1<t.size()&&c==0xC3){ // UTF-8 latino: remove acento das letras comuns do PT-BR
      unsigned char d=(unsigned char)t[++i];
      static const char* map="AAAAAAACEEEEIIIIDNOOOOO*OUUUUYTSaaaaaaaceeeeiiiidnooooo/ouuuuyty";
      int idx=(int)d-0x80;char r='?';if(idx>=0&&idx<(int)std::strlen(map))r=map[idx];
      o.push_back((char)std::toupper((unsigned char)r));continue;
    }
    if(c>=0x80){o.push_back('?');continue;}
    char u=(char)std::toupper(c);o.push_back(findGlyph(u)?u:'?');
  }
  return o;
}
int hudTextWidth(const std::string& text,int scale){return text.empty()?0:(int)text.size()*6*scale-scale;}
void hudDrawText(uint32_t*dst,int w,int h,int x,int y,const std::string& raw,uint32_t color,int scale,bool shadow){
  if(!dst||scale<=0)return;
  const std::string text=hudSanitize(raw);int cx=x;
  for(char ch:text){
    const Glyph*g=findGlyph(ch);if(g){
      for(int pass=shadow?0:1;pass<2;++pass){
        const int ox=pass==0?scale:0,oy=pass==0?scale:0;const uint32_t col=pass==0?0xff000000u:(0xff000000u|color);
        const char*r=g->rows;for(int row=0;row<7;++row){
          for(int bit=0;bit<5;++bit)if(r[bit]=='1')for(int sy=0;sy<scale;++sy)for(int sx=0;sx<scale;++sx)put(dst,w,h,cx+bit*scale+sx+ox,y+row*scale+sy+oy,col);
          r+=6;
        }
      }
    }
    cx+=6*scale;
  }
}
void hudFillRect(uint32_t*dst,int w,int h,int x,int y,int rw,int rh,uint32_t rgb,int alpha){
  if(!dst)return;
  alpha=std::clamp(alpha,0,255);const int x0=std::max(0,x),y0=std::max(0,y),x1=std::min(w,x+rw),y1=std::min(h,y+rh);
  for(int yy=y0;yy<y1;++yy)for(int xx=x0;xx<x1;++xx){
    uint32_t&d=dst[(size_t)yy*w+xx];
    auto mix=[&](int sh){int s=(rgb>>sh)&255,t=(d>>sh)&255;return uint32_t((s*alpha+t*(255-alpha))/255);};
    d=0xff000000u|(mix(16)<<16)|(mix(8)<<8)|mix(0);
  }
}
void hudOutlineRect(uint32_t*dst,int w,int h,int x,int y,int rw,int rh,uint32_t rgb){
  if(!dst||rw<=0||rh<=0)return;
  const uint32_t c=0xff000000u|rgb;
  for(int i=0;i<rw;++i){put(dst,w,h,x+i,y,c);put(dst,w,h,x+i,y+rh-1,c);}
  for(int j=0;j<rh;++j){put(dst,w,h,x,y+j,c);put(dst,w,h,x+rw-1,y+j,c);}
}
}
