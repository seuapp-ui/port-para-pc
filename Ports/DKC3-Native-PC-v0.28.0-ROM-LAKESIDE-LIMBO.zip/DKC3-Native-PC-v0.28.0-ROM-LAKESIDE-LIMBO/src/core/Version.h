#pragma once
namespace dkc3 {
constexpr const char* kVersion = "0.28.0";
constexpr const char* kVersionName = "ROM Lakeside Limbo Pass";
}
