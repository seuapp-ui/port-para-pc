#pragma once
#include "World.h"
#include "Player.h"
#include "NativeScene.h"
#include "NativeSprite.h"
#include "Animation.h"
#include "Hud.h"
#include "Audio.h"
#include "RomData.h"
#include <map>
#include <string>
#include <vector>
namespace dkc3 {
struct Camera { float x=0,y=0; int viewportW=256,viewportH=224; };
struct RuntimeSpriteObject { std::string id; Vec2 pos; bool foreground=false; NativeSprite sprite; };
struct RuntimeEnemy {
  std::string id; Vec2 pos; float speed=0,minX=0,maxX=0,w=24,h=24; bool facingRight=false,active=true;
  NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeLever { std::string id,gateId; Rect rect; Vec2 anchor; float holdTime=0.45f,progress=0.0f; bool activated=false; };
struct RuntimeGate { std::string id; Rect rect; bool open=false; NativeSprite sprite; };
struct RuntimeScenePage { float startX=0; std::string path; NativeScene scene; bool loaded=false; };
struct RuntimeCollectible {
  std::string id; Vec2 pos; float w=20,h=20; int value=1; bool active=true;
  NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeKongLetter {
  char letter='K'; Vec2 pos; float w=16,h=28; bool active=true;
  NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeTeamBarrel {
  std::string id; Vec2 pos; float w=30,h=38; bool active=true; NativeSprite sprite;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
enum class CharacterId { Dixie, Kiddy };
struct GamePersistentState { CharacterId activeCharacter=CharacterId::Dixie; bool partnerAvailable=true; int coins=0; };
class Game {
 public:
  bool init(const char* levelPath,const GamePersistentState* persistent=nullptr);
  void step(const InputState& in,float dt);
  void render(uint32_t* dst,int w,int h) const;
  const World& world()const{return world_;}
  const Player& player()const{return player_;}
  const NativeScene& scene()const{return scenePages_.empty()?scene_:scenePages_[activeScenePage_].scene;}
  bool hasNativeScene()const{return hasScene_||hasRomScene_;}
  bool hasRomScene()const{return hasRomScene_;}
  size_t scenePageCount()const{return hasRomScene_?1u:(scenePages_.empty()?(hasScene_?1u:0u):scenePages_.size());}
  size_t activeScenePage()const{return scenePages_.empty()?0u:activeScenePage_;}
  size_t loadedScenePageCount()const{size_t n=0;for(const auto& p:scenePages_)if(p.loaded)++n;return n;}
  bool scenePageLoaded(size_t index)const{return index<scenePages_.size()&&scenePages_[index].loaded;}
  const Camera& camera()const{return camera_;}
  const NativeSprite& playerSprite()const{return playerSprite_;}
  const NativeSprite& companionSprite()const{return companionSprite_;}
  Vec2 companionPos()const{return companionPos_;}
  const std::vector<RuntimeSpriteObject>& spriteObjects()const{return spriteObjects_;}
  const std::vector<RuntimeEnemy>& enemies()const{return enemies_;}
  const std::vector<RuntimeCollectible>& collectibles()const{return collectibles_;}
  const std::vector<RuntimeKongLetter>& kongLetters()const{return kongLetters_;}
  const std::vector<RuntimeTeamBarrel>& teamBarrels()const{return teamBarrels_;}
  const std::vector<RuntimeLever>& levers()const{return levers_;}
  const std::vector<RuntimeGate>& gates()const{return gates_;}
  const std::string& pendingLevel()const{return pendingLevel_;}
  Vec2 respawnPoint()const{return respawn_;}
  int coins()const{return coins_;}
  int damageCount()const{return damageCount_;}
  int defeatedEnemies()const{return defeatedEnemies_;}
  std::string playerAnimationState()const{return playerAnimState_;}
  std::string companionAnimationState()const{return companionAnimState_;}
  size_t playerAnimationFrame()const{return playerAnimator_.frame;}
  CharacterId activeCharacter()const{return activeCharacter_;}
  bool partnerAvailable()const{return partnerAvailable_;}
  bool attacking()const{return attackTimer_>0.0f;}
  bool attackActive()const;
  Rect attackBounds()const;
  float invulnerabilityTime()const{return invulnerableTimer_;}
  int characterSwitches()const{return characterSwitches_;}
  int leverActivations()const{return leverActivations_;}
  int checkpointActivations()const{return checkpointActivations_;}
  int lockedDoorAttempts()const{return lockedDoorAttempts_;}
  int teamBarrelRescues()const{return teamBarrelRescues_;}
  unsigned kongMask()const{return kongMask_;}
  int kongLettersCollected()const{return kongLettersCollected_;}
  bool leverActivated(const std::string& id)const;
  GamePersistentState persistentState()const{return {activeCharacter_,partnerAvailable_,coins_};}
  bool inWater()const{return inWater_;}
  bool inWaterCurrent()const{return inWaterCurrent_;}
  Vec2 activeWaterCurrent()const{return activeWaterCurrent_;}
  // v0.8.0: HUD, overlay de debug e transicao suave entre paginas de cena.
  void setHudEnabled(bool v){hudEnabled_=v;} bool hudEnabled()const{return hudEnabled_;}
  void setDebugOverlay(bool v){debugOverlay_=v;} bool debugOverlay()const{return debugOverlay_;}
  float levelTime()const{return levelTime_;}
  bool pageFading()const{return pageFade_<1.0f;}
  float pageFadeProgress()const{return pageFade_;}
  // v0.9.0: eventos de som emitidos desde a ultima chamada (a plataforma consome e toca).
  std::vector<Sfx> takeSfx(){std::vector<Sfx> o;o.swap(sfx_);return o;}
  void showToastPublic(const std::string& text,float seconds=1.2f){showToast(text,seconds);}
  const std::string& toast()const{return toast_;}
  float toastTime()const{return toastTimer_;}
 private:
  void emit(Sfx s){if(sfx_.size()<64)sfx_.push_back(s);}
  void showToast(const std::string& text,float seconds=1.6f){toast_=text;toastTimer_=seconds;}
  void renderScenePage(size_t index,uint32_t* dst,int w,int h)const;
  void renderRomScene(uint32_t* dst,int w,int h)const;
  void drawHud(uint32_t* dst,int w,int h)const;
  void drawDebug(uint32_t* dst,int w,int h)const;
  void updateCamera(float dt);
  bool ensureScenePageLoaded(size_t index);
  bool prefetchSceneWindow(size_t center);
  void trimScenePageCache();
  bool loadAnimationMap(const std::vector<AnimationDef>& defs,std::map<std::string,NativeAnimation>& out);
  std::string desiredPlayerAnimation()const;
  const NativeAnimation* findAnim(const std::map<std::string,NativeAnimation>& set,const std::string& key)const;
  const std::map<std::string,NativeAnimation>& activeAnimations()const;
  const std::map<std::string,NativeAnimation>& inactiveAnimations()const;
  const NativeSprite& activeFallbackSprite()const;
  const NativeSprite& inactiveFallbackSprite()const;
  void setPlayerAnimationState(const std::string& state);
  void switchCharacter(bool manualSwitch);
  void applyCharacterDimensions();
  void applyDamage(float enemyCenterX);
  void activateLever(size_t index);
  float attackDuration() const;
  float attackReach() const;
  World world_; Player player_; NativeScene scene_; bool hasScene_=false,hasRomScene_=false; RomLakesideLimboVisuals romLakeside_;
  std::vector<RuntimeScenePage> scenePages_; size_t activeScenePage_=0;
  Camera camera_; Vec2 respawn_{}; NativeSprite playerSprite_,companionSprite_; Vec2 companionPos_{};
  std::vector<RuntimeSpriteObject> spriteObjects_; std::vector<RuntimeEnemy> enemies_; std::vector<RuntimeCollectible> collectibles_;
  std::vector<RuntimeKongLetter> kongLetters_;
  std::vector<RuntimeTeamBarrel> teamBarrels_;
  std::vector<RuntimeLever> levers_; std::vector<RuntimeGate> gates_; std::vector<bool> checkpointActive_;
  std::map<std::string,NativeAnimation> dixieAnimations_,kiddyAnimations_;
  AnimationPlayer playerAnimator_,companionAnimator_; std::string playerAnimState_="idle",companionAnimState_="idle";
  std::string pendingLevel_; bool prevUp_=false,prevJump_=false,prevAttack_=false,prevSwitch_=false;
  int coins_=0,damageCount_=0,defeatedEnemies_=0,characterSwitches_=0,leverActivations_=0,checkpointActivations_=0,lockedDoorAttempts_=0,teamBarrelRescues_=0;
  unsigned kongMask_=0; int kongLettersCollected_=0;
  CharacterId activeCharacter_=CharacterId::Dixie; bool partnerAvailable_=true;
  float attackTimer_=0.0f,attackCooldown_=0.0f,invulnerableTimer_=0.0f;
  int activeLever_=-1; bool inWater_=false,inWaterCurrent_=false; Vec2 activeWaterCurrent_{};
  std::vector<Sfx> sfx_; bool prevGrounded_=false,prevInWater_=false,waterKnown_=false; float lastAirVy_=0.0f;
  bool hudEnabled_=true,debugOverlay_=false; float levelTime_=0.0f,toastTimer_=0.0f,pageFade_=1.0f; std::string toast_; size_t fadeFromPage_=0;
};
}
