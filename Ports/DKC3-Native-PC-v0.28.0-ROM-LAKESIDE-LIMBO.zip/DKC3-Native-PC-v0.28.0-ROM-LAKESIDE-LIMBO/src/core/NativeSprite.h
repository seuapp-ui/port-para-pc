#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace dkc3 {
struct NativeSprite {
  int width=0,height=0;
  int originX=0,originY=0;
  std::vector<uint32_t> bgra;
  bool valid() const { return width>0&&height>0&&bgra.size()==(size_t)width*height; }
};
bool loadNativeSprite(const std::string& path, NativeSprite& out);
void drawNativeSprite(const NativeSprite& s,uint32_t* dst,int w,int h,int x,int y,bool flipX=false);
uint64_t hashSprite(const NativeSprite& s);
}
