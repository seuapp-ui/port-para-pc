#include "core/RomData.h"
#include <cstdint>
#include <iostream>
using namespace dkc3;
static uint64_t fnvPixels(const std::vector<uint32_t>& v){uint64_t h=1469598103934665603ull;for(uint32_t x:v)for(int s=0;s<32;s+=8){h^=(x>>s)&255u;h*=1099511628211ull;}return h;}
static uint64_t fnvBytes(const std::vector<uint8_t>& v){uint64_t h=1469598103934665603ull;for(uint8_t x:v){h^=x;h*=1099511628211ull;}return h;}
int main(){
  RomFrontendVisuals f;if(!f.load("rom/dkc3_ptbr.sfc")){std::cerr<<"ROM frontend load failed\n";return 1;}
  if(!f.romInfo().valid||f.romInfo().size!=4194304u||f.romInfo().crc32!=0x448eec19u){std::cerr<<"ROM identity mismatch\n";return 2;}
  if(f.title().size()!=256u*224u||fnvPixels(f.title())!=0xde7ad96ff84b31a0ull){std::cerr<<"title decode mismatch\n";return 3;}
  if(f.fileSelect().size()!=256u*224u||fnvPixels(f.fileSelect())!=0xc04516d7d31d6e34ull){std::cerr<<"file select decode mismatch\n";return 4;}
  RomWorldMapVisuals m;if(!m.load("rom/dkc3_ptbr.sfc")){std::cerr<<"ROM world map load failed\n";return 5;}
  if(m.width()!=512||m.height()!=512||m.mapPixels().size()!=512u*512u||m.landMask().size()!=512u*512u){std::cerr<<"world map dimensions mismatch\n";return 6;}
  if(m.boatFrames().size()!=9u){std::cerr<<"boat pose count mismatch\n";return 7;}
  if(fnvPixels(m.mapPixels())!=0x3c94e156e2bcfddfull){std::cerr<<"world map decode mismatch\n";return 8;}
  if(fnvBytes(m.landMask())!=0x39a27635f67c1401ull){std::cerr<<"world map land mask mismatch\n";return 9;}
  uint64_t boatHash=1469598103934665603ull;
  for(const auto& frame:m.boatFrames())for(uint32_t x:frame.pixels)for(int sh=0;sh<32;sh+=8){boatHash^=(x>>sh)&255u;boatHash*=1099511628211ull;}
  if(boatHash!=0x8dd0a6704447a9dbull){std::cerr<<"boat pose decode mismatch\n";return 10;}
  if(m.boatBlocked(348.0f,420.0f)){std::cerr<<"safe water start unexpectedly blocked\n";return 11;}
  RomLakesideLimboVisuals lakeside;if(!lakeside.load("rom/dkc3_ptbr.sfc")){std::cerr<<"Lakeside Limbo ROM load failed\n";return 12;}
  if(lakeside.width()!=6240||lakeside.height()!=224||lakeside.pixels().size()!=6240u*224u||lakeside.foregroundMask().size()!=6240u*224u){std::cerr<<"Lakeside dimensions mismatch\n";return 13;}
  if(lakeside.placements().size()!=47u||lakeside.placementData().size()!=378u){std::cerr<<"Lakeside placement decode mismatch\n";return 14;}
  if(fnvPixels(lakeside.pixels())!=0xbd5b86def5f6df8aull){std::cerr<<"Lakeside scene decode mismatch\n";return 15;}
  if(fnvBytes(lakeside.foregroundMask())!=0x25a4d3f0c023284eull){std::cerr<<"Lakeside foreground mask mismatch\n";return 16;}
  if(fnvBytes(lakeside.placementData())!=0x4e0b107049bd98fdull){std::cerr<<"Lakeside placement blob mismatch\n";return 17;}
    RomLakeOrangatangaVisuals lake;if(!lake.load("rom/dkc3_ptbr.sfc")){std::cerr<<"Lake Orangatanga load failed\n";return 18;}
  if(lake.mapPixels().size()!=256u*224u||lake.collisionData().size()!=155u||lake.dixieWalkFrames().size()!=8u){std::cerr<<"Lake Orangatanga dimensions mismatch\n";return 19;}
  if(fnvPixels(lake.mapPixels())!=0x66ff253611fa8c71ull){std::cerr<<"Lake Orangatanga map decode mismatch\n";return 20;}
  if(fnvBytes(lake.collisionData())!=0x527bb393335c2a88ull){std::cerr<<"Lake Orangatanga collision blob mismatch\n";return 21;}
  uint64_t dixieHash=1469598103934665603ull;for(const auto& frame:lake.dixieWalkFrames())for(uint32_t x:frame.pixels)for(int sh=0;sh<32;sh+=8){dixieHash^=(x>>sh)&255u;dixieHash*=1099511628211ull;}
  if(dixieHash!=0x91370acfa83e204eull){std::cerr<<"Lake Orangatanga Dixie walk decode mismatch\n";return 22;}
  std::cout<<"ROM_DATA_OK CRC32=448eec19 title/file-select/main-map/boat/lakeside/lake\n";return 0;
}
