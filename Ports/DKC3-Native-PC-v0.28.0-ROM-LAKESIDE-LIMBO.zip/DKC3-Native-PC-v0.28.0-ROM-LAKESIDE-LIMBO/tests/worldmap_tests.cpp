#include "core/WorldMap.h"
#include "core/NativeScene.h"
#include <iostream>
#include <vector>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" expr="<<#x<<"\n";return 10;}}while(0)
namespace {
void settle(dkc3::WorldMap& m){dkc3::WorldMapInput none;for(int i=0;i<40;++i)m.step(none,1.0f/60.0f);}
bool waitLaunch(dkc3::WorldMap& m,std::string& level){dkc3::WorldMapInput none;for(int i=0;i<50;++i){m.step(none,1.0f/60.0f);if(m.takeLaunchRequest(level))return true;}return false;}
}
int main(){
  using namespace dkc3;
  const unsigned lakeside=WorldMap::stageBit("lakeside-limbo");
  const unsigned doorstop=WorldMap::stageBit("doorstop");
  const unsigned tidal=WorldMap::stageBit("tidal-trouble");
  const unsigned skidda=WorldMap::stageBit("skiddas-row");
  WorldMapState fresh;fresh.area=(int)WorldArea::LakeOrangatanga;fresh.lakeNode=0;fresh.unlockedMask=lakeside;
  WorldMap first;CHECK(first.init(fresh,"rom/dkc3_ptbr.sfc"));first.setRuntimeAvailableMask(lakeside|doorstop|tidal);first.setCurrentLevel("lakeside-limbo");settle(first);WorldMapInput firstOk;firstOk.confirm=true;first.step(firstOk,1.0f/60.0f);std::string firstLevel;CHECK(waitLaunch(first,firstLevel));CHECK(firstLevel=="lakeside-limbo");

  WorldMapState s;s.boatX=430;s.boatY=420;s.unlockedMask=lakeside|doorstop;s.completedMask=lakeside;s.area=(int)WorldArea::NorthernKremisphere;s.lakeNode=1;
  WorldMap m;CHECK(m.init(s,"rom/dkc3_ptbr.sfc"));CHECK(m.romBacked());m.setRuntimeAvailableMask(lakeside|doorstop|tidal);m.setCurrentLevel("doorstop");settle(m);
  std::vector<uint32_t> fb(256*224);m.render(fb.data(),256,224);const auto h0=hashFrame(fb.data(),fb.size());CHECK(h0!=0);
  // Main-map gateway now enters the ROM-backed Lake Orangatanga submap.
  WorldMapInput ok;ok.confirm=true;m.step(ok,1.0f/60.0f);CHECK(m.area()==WorldArea::LakeOrangatanga);settle(m);CHECK(m.currentLevel()=="doorstop");
  m.render(fb.data(),256,224);CHECK(hashFrame(fb.data(),fb.size())!=h0);
  // Doorstop can be launched because it exists in the current native runtime.
  ok.confirm=false;m.step(ok,1.0f/60.0f);ok.confirm=true;m.step(ok,1.0f/60.0f);std::string level;CHECK(waitLaunch(m,level));CHECK(level=="doorstop");
  // Completing Doorstop unlocks the correct next Lake Orangatanga stage: Tidal Trouble.
  ok.confirm=false;m.completeStage("doorstop","tidal-trouble");CHECK((m.state().completedMask&doorstop)!=0);CHECK((m.state().unlockedMask&tidal)!=0);CHECK(m.currentLevel()=="tidal-trouble");settle(m);
  ok.confirm=true;m.step(ok,1.0f/60.0f);CHECK(waitLaunch(m,level));CHECK(level=="tidal-trouble");
  // Completing Tidal unlocks Skidda, but it is honestly blocked until its native level exists.
  ok.confirm=false;m.completeStage("tidal-trouble","skiddas-row");CHECK((m.state().completedMask&tidal)!=0);CHECK((m.state().unlockedMask&skidda)!=0);settle(m);ok.confirm=true;m.step(ok,1.0f/60.0f);CHECK(!m.takeLaunchRequest(level));CHECK(m.toast()=="FASE AINDA NAO PORTADA");
  // A backward/test exit must not falsely mark Skidda complete.
  const unsigned before=m.state().completedMask;m.completeStage("skiddas-row","tidal-trouble");CHECK(m.state().completedMask==before);
  std::cout<<"WORLDMAP_ROM_LAKE_TESTS_OK\n";return 0;
}
