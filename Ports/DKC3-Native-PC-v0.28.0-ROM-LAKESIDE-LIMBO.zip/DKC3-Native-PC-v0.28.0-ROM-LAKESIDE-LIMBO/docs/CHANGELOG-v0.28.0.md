# Changelog v0.28.0

- Adicionado `RomLakesideLimboVisuals`.
- Decodificacao ROM-first de RiverbankLevels, Map32, Layer1, Layer2 e paleta de Lakeside.
- Cenario de Lakeside Limbo com 6240 px de largura carregado pelo motor C++.
- Novo comando de nivel `rom_scene lakeside-limbo`.
- `Game` ganhou caminho de render ROM-first sem `.nscene`.
- Lakeside adicionada ao catalogo real de fases e ao `runtimeMapMask` do launcher Windows.
- 47 placements originais decodificados da ROM e preservados para traducao de entidades.
- Checkpoint e goal de Lakeside integrados ao fluxo; goal leva para Doorstop Dash.
- Teste automatizado atravessa Lakeside e exige checkpoint + saida para Doorstop.
- Hashes congelados para pixels, foreground mask e blob de placements.
- Mantidos Title, File Select, Main Map e Lake Orangatanga ROM-first das versoes anteriores.
- Nenhuma dependencia de Mesen, Oracle, `.state` ou sistema de captura foi reintroduzida.
