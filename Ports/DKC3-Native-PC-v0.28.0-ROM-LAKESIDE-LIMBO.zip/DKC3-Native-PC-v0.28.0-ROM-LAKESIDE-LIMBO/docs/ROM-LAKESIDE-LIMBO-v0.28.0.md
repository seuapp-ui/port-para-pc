# DKC3 Native PC v0.28.0 — ROM Lakeside Limbo

Esta versao coloca **Lakeside Limbo**, a primeira fase de Lake Orangatanga, dentro do runtime nativo.

## Fonte do cenario

O runtime abre `rom/dkc3_ptbr.sfc` e descompacta diretamente os blocos originais usados pela fase:

- `RiverbankLevels` — mapa da fase;
- `Map32 Riverbank` — definicoes dos metatiles 32x32;
- `Layer1 Riverbank` — tiles 4bpp;
- `Layer2 Riverbank` — fundo;
- paleta `LakesideLimbo`;
- tabela de placements `LakesideLimbo_Main`.

Os primeiros 195 columns x 16 rows do mapa horizontal formam um cenario de **6240 x 512 px**. O runtime apresenta uma janela vertical de 224 px adequada a Lakeside e mantem 6240 px completos no eixo X.

## Fluxo jogavel

`Title -> File Select -> Northern Kremisphere -> Lake Orangatanga -> Lakeside Limbo -> Doorstop Dash`

- Lakeside agora existe em `levels.index` e pode ser escolhida pelo submapa.
- O checkpoint usa o X original convertido do espaco SNES para o espaco local da fase.
- O warp final usa `0x1880 - 0x0100 = 0x1780` como referencia do fim do mapa e retorna `doorstop`.
- Um teste atravessa a fase inteira e confirma checkpoint + `target=doorstop`.

## Objetos originais

A tabela em ROM `$FE05B2-$FE072C` e decodificada em registros de 8 bytes (`parameter, x, y, type`). Foram encontrados **47 placements** antes do terminador zero. Eles sao preservados por `RomLakesideLimboVisuals` e protegidos por hash para a proxima etapa, que traduzira os tipos de objeto para comportamentos nativos.

## Limite atual

O **visual completo do terreno vem da ROM**, mas a colisao fisica usada para atravessar a fase nesta versao ainda e um scaffold horizontal. O formato original de colisao/terreno e o comportamento dos 47 placements ainda precisam ser traduzidos. Portanto v0.28 torna Lakeside realmente carregavel e atravessavel, mas ainda nao e uma implementacao 100% fiel de inimigos, barris, bonus e relevo fisico.
