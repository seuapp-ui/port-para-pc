@echo off
cd /d "%~dp0"
TestCore.exe
if errorlevel 1 goto erro
TestPlayer.exe
if errorlevel 1 goto erro
TestEntities.exe
if errorlevel 1 goto erro
TestHD.exe
if errorlevel 1 goto erro
echo Testes concluidos.
pause
exit /b 0
:erro
echo Falha nos testes.
pause
exit /b 1
