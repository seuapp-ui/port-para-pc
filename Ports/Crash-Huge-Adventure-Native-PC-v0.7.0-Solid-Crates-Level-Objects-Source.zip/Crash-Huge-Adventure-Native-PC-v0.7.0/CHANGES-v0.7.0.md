# Mudanças — v0.7.0

- Caixas deixam de ser apenas entidades desenhadas e passam a funcionar como **corpos sólidos nativos**.
- A colisão não usa mais um quadrado aproximado: o runtime lê **offset X/Y + largura/altura diretamente do registro de animação da ROM**. Na família de caixas da primeira sala isso resolve em caixas físicas de 19×19 px.
- O jogador agora pode ficar em cima de caixas, ser bloqueado lateralmente por elas, bater por baixo e caminhar sobre pilhas.
- Pilhas metálicas da fase passam a respeitar o empilhamento real em incrementos de 20 px sem o Crash atravessar os blocos.
- A caixa metálica com seta (tipo 29 / animação 2) passa a funcionar como superfície de impulso vertical.
- A caixa listrada/bounce (tipo 33 / animação 25) passa a devolver impulso ao Crash quando atingida por cima; giro ainda pode destruí-la.
- Recuperado um dado importante dos registros da fase: tipos **32 e 36** copiam o byte `+6` para o contador `+0x51` do objeto original. O código original incrementa um contador de ativações até esse limite.
- O port agora lê esse limite diretamente da ROM. Na primeira sala existem limites de **5 e 10 ativações**, totalizando 45 ativações possíveis além dos 26 Wumpas colocados no mapa.
- Cada ativação válida desses dois tipos soma um Wumpa no runtime e a caixa só é encerrada quando o limite do registro é alcançado (ou é quebrada diretamente pelo giro).
- A colisão de Nitro/TNT foi adaptada para o novo sistema sólido: o contato é detectado na borda física, sem exigir que o corpo do Crash atravesse o sprite.
- Implementado o primeiro objeto de nível fora da família de caixas: **entidade tipo 86**.
- O tipo 86 segue a rota original `sub_802190C -> sub_801A878`; no estado normal da primeira sala usa o **banco 39 / animação 5**. O sprite e a caixa física (37×15 px) vêm da ROM.
- O tipo 86 é desenhado e participa da lista de sólidos; o preview desta versão mostra o Crash apoiado nele.
- HUD ganhou indicador simples da proteção Aku quando ativa.
- Replay diagnóstico foi ajustado para testar uma pilha real de caixas: o Crash fica bloqueado corretamente e o giro abre a passagem.
- `TestEntities` agora cobre limites 5/10 lidos da ROM, caixas sólidas, piso de caixa, caixa metálica com seta, objeto 86, além dos testes anteriores.
- Build C++ limpo com `-Wall -Wextra -Wpedantic`.

## Fidelidade / limites desta etapa

O formato físico das caixas e do objeto 86 vem dos registros de animação reais da ROM. O byte de limite usado pelos tipos 32/36 e a lógica de “contador até o cap” também vêm do código decompilado original. A associação de cada ativação desses tipos a um Wumpa no port continua sendo uma reconstrução de gameplay até a rotina de recompensa ser fechada por completo.

O tipo 86 da primeira sala não possui deslocamento no registro usado aqui e é tratado como objeto sólido estático. O sistema genérico de `mover` do jogo original já foi identificado na decompilação, mas plataformas móveis de outras salas ainda não foram integradas ao runtime PC.

## Próximo bloco

Prioridade: portar o sistema genérico de objetos/movers para tipos de outras salas, identificar os primeiros inimigos com sprite + comportamento, e iniciar a transição entre salas da mesma fase.
