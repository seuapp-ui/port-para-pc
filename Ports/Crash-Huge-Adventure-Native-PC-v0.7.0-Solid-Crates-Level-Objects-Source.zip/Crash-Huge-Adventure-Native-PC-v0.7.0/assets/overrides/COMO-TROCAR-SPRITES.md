# Como trocar os sprites do Crash

Os quatro PNGs desta pasta são folhas **editáveis**, exportadas dos gráficos originais em escala 4×. Ainda não são desenhos novos em HD. Cada célula mede **256×256 pixels**, equivalente a **64×64 unidades do jogo**.

## Caminho mais fácil

1. Faça uma cópia do PNG antes de editar.
2. Abra `crash-idle.png` (parado), `crash-run.png` (andando), `crash-air.png` (no ar) ou `crash-spin.png` (giro) num editor com transparência.
3. Desenhe o novo personagem sobre cada célula, mantendo o tamanho total da folha e a posição dos pés/corpo. Não reorganize as células.
4. Salve em PNG com transparência, com o mesmo nome.
5. No jogo, pressione **F5**. As folhas são recarregadas sem reiniciar o personagem.
6. Pressione **H** para comparar com os sprites da ROM. **C** mostra o retângulo de colisão; ele não muda com o desenho.

O ponto de referência do personagem fica em (128,160) dentro de cada célula 256×256. Ele corresponde ao mesmo ponto usado pelos frames da ROM, não necessariamente à sola dos pés. O corpo de colisão é (-7,-27,14,41) nas coordenadas originais.

Folhas atuais: 10 células para parado, 20 para andar, 15 para no ar e 10 para giro, todas em uma linha. `manifest.csv` associa os 55 frames às células. A duração e a ordem das animações continuam vindo da ROM. O espelhamento para esquerda é feito pelo renderizador.

## PNG individual ou outra resolução

Edite a linha correspondente no `manifest.csv`. Exemplo de PNG individual 256×256 para um frame existente:

```
0,NUMERO_DO_FRAME,PALETA,meu-crash.png,0,0,256,256,-32,-40,64,64
```

Copie o número do frame e da paleta da linha existente. Esse exemplo é ilustrativo; não use os nomes NUMERO_DO_FRAME/PALETA literalmente.

| Coluna | Significado |
|---|---|
| bank, frame, palette | Identificação original na ROM; copie da linha que quer substituir |
| file | PNG relativo a esta pasta; use `/` em subpastas |
| src_x, src_y | Início do recorte na imagem, em pixels do PNG |
| src_w, src_h | Tamanho do recorte, em pixels do PNG |
| origin_x, origin_y | Posição do canto do desenho em relação ao personagem, em unidades originais |
| logical_width, logical_height | Espaço ocupado pelo recorte no cenário, em unidades originais |

Um recorte de 512×512 com espaço lógico 64×64 ocupa o mesmo tamanho no jogo. Basta atualizar `src_w/src_h` e manter as colunas lógicas. Para uma folha inteira duplicada de tamanho, duplique também `src_x/src_y/src_w/src_h` de suas linhas.

Não coloque vírgulas nos nomes de arquivos. Caminhos absolutos e `..` são rejeitados. Limites: 32 MiB por arquivo PNG; até 8.192 por dimensão e 16 milhões de pixels por imagem; 128 MiB de texturas decodificadas por carregamento. A transparência parcial é aceita.

## Quando um arquivo não funciona

A linha inválida fica sem substituição e usa o frame da ROM. Consulte `exports/sprite-load-report.txt`: ele informa quantos frames carregaram e o motivo dos erros. F5 atualiza o relatório. Um arquivo ausente ou PNG quebrado não deve impedir o jogo de abrir.

## Resoluções e alcance desta versão

F6 alterna 240×160, 960×640 e 1440×960. Para manter a escolha ao abrir novamente, edite `render_scale` em `display.ini` na raiz: 1, 4 ou 6. `external_sprites=0` abre usando a ROM; 1 habilita os PNGs.

Os novos PNGs são desenhados diretamente na resolução interna escolhida: detalhes menores que um pixel lógico podem aparecer em 960×640/1440×960. As colisões e a física permanecem nas coordenadas originais. Na tela cheia, a imagem é ajustada à área disponível com barras para preservar a proporção 3:2.

O carregamento está integrado ao personagem jogável. O cenário continua usando tiles da ROM ampliados; não há substituição de backgrounds, Wumpas, HUD ou áudio nesta versão; Wumpas e HUD são renderizados pelo runtime a partir da ROM/código nativo. Os inspetores antigos continuam usando seu renderizador de inspeção.

Para recriar as folhas originais, com Python e os requisitos de análise instalados, execute `python tools/export_replacement_templates.py` a partir da raiz. Isso **sobrescreve suas edições e o manifest**; faça backup antes. O programa Windows já abre sem Python.
