@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Crash Native v0.7.0 - Build Windows x64
set "VSCMD_SKIP_SENDTELEMETRY=1"

where cl >nul 2>nul
if not errorlevel 1 goto :compiler_ok

for %%V in (
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
) do if exist "%%~V" (
  echo Carregando ambiente C++: %%~V
  call "%%~V" >nul
  goto :compiler_check
)

:compiler_check
where cl >nul 2>nul
if not errorlevel 1 goto :compiler_ok

echo.
echo ERRO: compilador C++ do Visual Studio 2022 nao encontrado.
echo Instale "Desktop development with C++" no Visual Studio Build Tools.
echo Depois execute este arquivo novamente.
pause
exit /b 1

:compiler_ok
echo ============================================
echo  Crash Native v0.7.0 - Windows x64
cl 2>&1 | findstr /i "Version" 
echo ============================================

call :buildwin CrashNative.exe "src\game_win32.cpp src\png.cpp" "/link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib" || goto :erro
call :build CrashGameplayTool.exe src\gameplay_tool.cpp || goto :erro
call :build TestPlayer.exe tests\test_player.cpp || goto :erro
call :build TestEntities.exe tests\test_entities.cpp || goto :erro
call :buildwin CrashNative-Scene.exe "src\scene_win32.cpp" "/link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib" || goto :erro
call :build CrashSceneTool.exe src\scene_tool.cpp || goto :erro
call :buildwin CrashNative-Inspector.exe "src\viewer_win32.cpp" "/link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib" || goto :erro
call :build CrashRomTool.exe src\inspect.cpp || goto :erro
call :build TestCore.exe tests\test_core.cpp || goto :erro
call :build CrashHDTool.exe "src\hd_tool.cpp src\png.cpp" || goto :erro
call :build TestHD.exe "tests\test_hd.cpp src\png.cpp" || goto :erro

echo.
echo Executando testes...
TestCore.exe || goto :erro
TestPlayer.exe || goto :erro
TestEntities.exe || goto :erro
TestHD.exe || goto :erro

echo v0.7.0>BUILD-WINDOWS-VERSION.txt
echo.
echo OK: CrashNative.exe v0.7.0 foi gerado e os testes passaram.
echo Agora execute ABRIR-JOGO.cmd.
pause
exit /b 0

:build
set "OUT=%~1"
set "SRC=%~2"
echo [C++] %OUT%
cl /nologo /std:c++17 /EHsc /O2 /MT %SRC% /Fe:%OUT%
exit /b %errorlevel%

:buildwin
set "OUT=%~1"
set "SRC=%~2"
set "LINK=%~3"
echo [C++] %OUT%
cl /nologo /std:c++17 /EHsc /O2 /MT %SRC% /Fe:%OUT% %LINK%
exit /b %errorlevel%

:erro
echo.
echo FALHA ao compilar/testar a v0.7.0.
echo Copie a mensagem de erro exibida acima para eu corrigir.
pause
exit /b 1
