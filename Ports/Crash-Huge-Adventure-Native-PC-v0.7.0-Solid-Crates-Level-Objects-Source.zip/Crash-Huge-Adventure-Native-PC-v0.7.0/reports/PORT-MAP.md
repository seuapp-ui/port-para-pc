# Estado do port v0.7.0

## Runtime já nativo

- Decoder da ROM USA ACQE e bancos de sprites.
- Render das camadas da sala e perfis reais de colisão do terreno.
- Crash: andar, rampas, salto/salto curto, giro, câmera e respawn.
- Parser dos 79 registros de entidade da primeira sala.
- 26 Wumpas colocados, com 14 frames originais e coleta.
- Família de caixas 21–39 ligada ao banco 31, 40 registros na primeira sala.
- Caixa física das animações lida da ROM e integrada ao solver do Player.
- Colisão por cima, lados e baixo; pilhas de caixas são superfícies reais.
- Metal, metal-arrow, bounce, checkpoint C, Aku, vida, Nitro e TNT.
- Tipos 32/36 com cap original do parâmetro `+6`: 5/10 nesta sala.
- Primeiro objeto não-caixa: tipo 86, banco 39/animação 5, caixa física 37×15.
- Efeitos de quebra/explosão com sprites originais.
- HUD de Wumpas, caixas e Aku.
- Substituição PNG HD para Crash com fallback à ROM.

## Dados confirmados nesta versão

A família de caixas usa os registros de animação apontados pelo construtor físico original. O corpo do port é calculado a partir de `offX`, `offY`, largura e altura do próprio registro, e não de um retângulo desenhado manualmente.

Os tipos 32 e 36 entram em caminhos do construtor que copiam o byte `+6` do parâmetro da entidade para o campo `+0x51`. A rotina física original mantém em `+0x50` o contador sucessivo e o compara contra esse limite. Na primeira sala, os registros ativos usam 5 e 10; a soma dos limites das caixas colocadas é 45.

A entidade tipo 86 segue o dispatcher até `sub_802190C -> sub_801A878`. No estado normal da primeira sala, a escolha resulta no tipo visual usado em banco 39/animação 5. A caixa física desse registro é 37×15 px.

## Reconstruções ainda provisórias

- Cada ativação dos tipos 32/36 entregar um Wumpa é implementação do port; o contador/cap é confirmado, a recompensa exata ainda não.
- Tipo 86 está estático nesta sala; o `mover` genérico do original está identificado, mas ainda não foi ligado ao runtime PC.
- Temporização/propagação de TNT/Nitro ainda será confrontada mais profundamente com as rotinas originais.

## Ainda pendente

- integrar `mover` e plataformas móveis;
- primeiros inimigos com AI/colisão/dano;
- animação final de dano/morte;
- áudio;
- transição entre salas/fases e objetivo de fim;
- mapa, menus, save/progressão.

## Validação

`make test` cobre TestCore, TestPlayer, TestEntities e TestHD. O replay de 360 ticks testa uma pilha real: a colisão segura o Crash e o giro abre a passagem. A entrega é ainda verificada com sanitizadores e com comparação independente C++/Python dos sprites/mapas/cena.
