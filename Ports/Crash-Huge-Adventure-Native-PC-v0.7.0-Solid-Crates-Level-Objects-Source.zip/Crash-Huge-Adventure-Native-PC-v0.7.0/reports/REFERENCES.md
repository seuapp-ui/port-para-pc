# Referências e origem dos dados

- ROM USA ACQE enviada pelo usuário; todos os recursos deste pacote foram lidos dela.
- [CrashBandicootXS-decomp](https://github.com/Almamu/CrashBandicootXS-decomp), de Almamu e colaboradores, commit `1f417177c20de6836370ecaa0a9f266923e56bbe`. Consultados os layouts documentados de bancos de sprites, peças, sequências, paletas e mapas de salas, além dos leitores de cache de paletas. O projeto trabalha com a ROM europeia e ainda está em andamento.
- [Formato de salas](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/docs/levels.md).
- [Layout dos bancos](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/include/sprite_bank.h).
- [Leitor de cache de paletas](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/src/graphics/graphics.c).
- [GBATEK](https://mgba-emu.github.io/gbatek/): formatos de tiles e cores de GBA.

O código C++/Python da prévia foi escrito para este port com verificações de limites. Não foi copiado o código-fonte nem o conteúdo gráfico da decompilação de referência. Os endereços europeus serviram de pista; a descoberta e a validação foram realizadas sobre os bytes da ROM americana fornecida.
