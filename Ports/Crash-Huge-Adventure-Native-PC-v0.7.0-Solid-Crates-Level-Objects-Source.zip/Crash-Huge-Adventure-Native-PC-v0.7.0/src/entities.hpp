#pragma once
#include "player.hpp"
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
namespace crash {
struct RuntimeEntity {Entity source;bool active=true;unsigned stateTicks=0,countdown=0;bool triggered=false;unsigned hits=0,triggerCap=0;};
struct EntityEffect {double x=0,y=0;unsigned animation=0,ticks=0;};
struct EntityClip {std::vector<Frame> frames;unsigned duration=1,flags=0;};
class EntityWorld {
 public:
 static constexpr unsigned WumpaType=6,CrateFirst=21,CrateLast=39,LevelPlatformType=86;
 static constexpr unsigned CheckpointCrateType=22,AkuCrateType=23,LifeCrateType=30,NitroCrateType=31,QuestionCrateType=32,BounceCrateType=33,TntCrateType=35,CounterCrateType=36;
 std::vector<RuntimeEntity> items;
 std::vector<Frame> wumpaFrames;
 std::array<EntityClip,36> crateClips{};
 std::array<Player::SolidBox,36> crateBounds{};
 EntityClip platformClip{};
 Player::SolidBox platformBounds{};
 std::vector<EntityEffect> effects;
 std::vector<Player::SolidBox> solids;
 unsigned wumpaCollected=0,wumpaTotal=0,wumpaPlaced=0,crateBroken=0,crateTotal=0,checkpointHits=0,akuMasks=0,extraLives=0,hazardHits=0,platformTotal=0,ticks=0;
 EntityWorld(const GameData& data,const Scene& scene){
  for(auto e:data.entities(scene)){
   RuntimeEntity r{e,true,0,0,false,0,0};
   if(e.type==QuestionCrateType||e.type==CounterCrateType)r.triggerCap=parameterByte(data,scene,e.param,6);
   items.push_back(r);
   if(e.type==WumpaType){++wumpaPlaced;++wumpaTotal;}
   if(isCrate(e.type)){++crateTotal;wumpaTotal+=r.triggerCap;}
   if(e.type==LevelPlatformType)++platformTotal;
  }
  loadWumpaFrames(data);loadCrateClips(data);loadPlatformClip(data);
  if(wumpaPlaced && wumpaFrames.size()!=14)throw std::runtime_error("Wumpa frame set incomplete");
  if(data.banks.at(31).animations.size()!=36)throw std::runtime_error("Crate bank revision");
  rebuildSolids();
 }
 static bool isCrate(unsigned type){return type>=CrateFirst&&type<=CrateLast;}
 static unsigned crateAnimation(unsigned type){
  // USA ACQE: level entity 21..39 -> level dispatch -> physics box constructor -> bank 31 animation tag.
  static constexpr unsigned map[19]={31,26,23,3,24,21,4,32,2,28,5,0,25,6,17,7,14,15,16};
  if(!isCrate(type))throw std::runtime_error("Not a crate entity type");
  return map[type-CrateFirst];
 }
 static bool metalCrate(unsigned type){return type==28||type==29;}
 static bool metalArrowCrate(unsigned type){return type==29;}
 static bool nitroCrate(unsigned type){return type==NitroCrateType;}
 static bool tntCrate(unsigned type){return type==TntCrateType;}
 static bool repeatedTriggerCrate(unsigned type){return type==QuestionCrateType||type==CounterCrateType;}
 void bind(Player& p){rebuildSolids();p.setDynamicSolids(&solids);}
 void reset(){for(auto& e:items){e.active=true;e.stateTicks=e.countdown=e.hits=0;e.triggered=false;}effects.clear();wumpaCollected=crateBroken=checkpointHits=akuMasks=extraLives=hazardHits=ticks=0;rebuildSolids();}
 void step(Player& p){
  ++ticks;for(auto& fx:effects)++fx.ticks;effects.erase(std::remove_if(effects.begin(),effects.end(),[&](const EntityEffect& fx){return fx.ticks>=effectLength(fx.animation);}),effects.end());
  auto body=p.bodyBox(),attack=p.attackBox();
  for(auto& e:items){
   if(!e.active)continue;
   ++e.stateTicks;
   if(e.source.type==WumpaType){if(overlap(body,entityBox(e))){e.active=false;++wumpaCollected;}continue;}
   if(!isCrate(e.source.type))continue;
   if(e.triggered&&e.countdown){--e.countdown;if(!e.countdown){explode(e,p);body=p.bodyBox();attack=p.attackBox();}continue;}
   const auto box=entityBox(e);
   const bool spinHit=p.spinning()&&overlap(attack,box);
   const bool contact=touch(body,box,.75);
   const bool onTop=p.lastDownImpact>1.0&&horizontal(body,box)&&std::abs(body[3]-box[1])<1.25;
   const bool fromBelow=p.lastUpImpact<-.8&&horizontal(body,box)&&std::abs(body[1]-box[3])<1.25;
   if(nitroCrate(e.source.type)){
    if(spinHit||contact){e.active=false;++crateBroken;effects.push_back({double(e.source.x),double(e.source.y),35,0});hurt(p);body=p.bodyBox();attack=p.attackBox();}
    continue;
   }
   if(metalCrate(e.source.type)){
    if(onTop&&metalArrowCrate(e.source.type))p.bounce(-7.2);
    continue;
   }
   if(tntCrate(e.source.type)){
    if(spinHit){e.triggered=true;e.countdown=8;}
    else if(onTop||fromBelow){e.triggered=true;e.countdown=180;if(onTop)p.bounce();}
    continue;
   }
   if(spinHit){breakCrate(e,p);body=p.bodyBox();attack=p.attackBox();continue;}
   if(onTop&&e.source.type==BounceCrateType){p.bounce(-7.0);continue;}
   if((onTop||fromBelow)&&repeatedTriggerCrate(e.source.type)&&e.triggerCap){
    ++e.hits;++wumpaCollected;e.stateTicks=0;
    if(e.hits>=e.triggerCap)breakCrate(e,p,false);else if(onTop)p.bounce(-5.7);
    body=p.bodyBox();attack=p.attackBox();continue;
   }
   if(onTop||fromBelow){breakCrate(e,p);if(onTop)p.bounce();body=p.bodyBox();attack=p.attackBox();}
  }
  rebuildSolids();
 }
 void renderLogical(std::vector<uint32_t>& canvas,int w,int h,int cameraX,int cameraY,bool hud=true)const{
  if(!wumpaFrames.empty()){
   const auto& f=wumpaFrames[(ticks/4)%wumpaFrames.size()];
   for(const auto& e:items)if(e.active&&e.source.type==WumpaType)GameData::blit(canvas,w,h,f,int(e.source.x)-cameraX,int(e.source.y)-cameraY);
  }
  for(const auto& e:items)if(e.active&&e.source.type==LevelPlatformType){const Frame* f=clipFrame(platformClip,e.stateTicks);if(f)GameData::blit(canvas,w,h,*f,int(e.source.x)-cameraX,int(e.source.y)-cameraY);}
  for(const auto& e:items)if(e.active&&isCrate(e.source.type)){
   unsigned anim=crateAnimation(e.source.type);unsigned local=e.stateTicks;
   if(tntCrate(e.source.type)&&e.triggered){unsigned phase=e.countdown>120?18:e.countdown>60?19:20;anim=phase;local=e.stateTicks;}
   const Frame* f=clipFrame(anim,local);if(f)GameData::blit(canvas,w,h,*f,int(e.source.x)-cameraX,int(e.source.y)-cameraY);
  }
  for(const auto& fx:effects){const Frame* f=clipFrame(fx.animation,fx.ticks);if(f)GameData::blit(canvas,w,h,*f,int(std::lround(fx.x))-cameraX,int(std::lround(fx.y))-cameraY);}
  if(hud){
   if(!wumpaFrames.empty()){GameData::blit(canvas,w,h,wumpaFrames[(ticks/4)%wumpaFrames.size()],14,15);drawX(canvas,w,h,27,8);drawNumber(canvas,w,h,34,7,wumpaCollected);}
   if(const Frame* box=clipFrame(31,0)){GameData::blit(canvas,w,h,*box,78,15);drawX(canvas,w,h,91,8);drawNumber(canvas,w,h,98,7,crateBroken);}
   if(akuMasks){drawLetterA(canvas,w,h,139,7);drawX(canvas,w,h,146,8);drawNumber(canvas,w,h,153,7,akuMasks);}
  }
 }
 Player::SolidBox entityBox(const RuntimeEntity& e)const{
  if(isCrate(e.source.type)){auto q=crateBounds[crateAnimation(e.source.type)];return {e.source.x+q[0],e.source.y+q[1],e.source.x+q[2],e.source.y+q[3]};}
  if(e.source.type==LevelPlatformType)return {e.source.x+platformBounds[0],e.source.y+platformBounds[1],e.source.x+platformBounds[2],e.source.y+platformBounds[3]};
  return {double(e.source.x-12),double(e.source.y-12),double(e.source.x+12),double(e.source.y+12)};
 }
 private:
 static unsigned parameterByte(const GameData& data,const Scene& scene,unsigned index,unsigned off){uint32_t list=data.rom.w(scene.descriptor+28),offsets=data.rom.w(list+8),params=data.rom.w(list+12);return data.rom.b(params+data.rom.h(offsets+2*index)+off);}
 static bool overlap(const std::array<double,4>& a,const std::array<double,4>& b){return a[0]<b[2]&&a[2]>b[0]&&a[1]<b[3]&&a[3]>b[1];}
 static bool touch(const std::array<double,4>& a,const std::array<double,4>& b,double eps){return a[0]<=b[2]+eps&&a[2]>=b[0]-eps&&a[1]<=b[3]+eps&&a[3]>=b[1]-eps;}
 static bool horizontal(const std::array<double,4>& a,const std::array<double,4>& b){return a[2]>b[0]+.5&&a[0]<b[2]-.5;}
 void rebuildSolids(){solids.clear();solids.reserve(crateTotal+platformTotal);for(const auto& e:items)if(e.active&&(isCrate(e.source.type)||e.source.type==LevelPlatformType))solids.push_back(entityBox(e));}
 void breakCrate(RuntimeEntity& e,Player& p,bool reward=true){
  if(!e.active)return;
  e.active=false;++crateBroken;effects.push_back({double(e.source.x),double(e.source.y),29,0});
  if(e.source.type==CheckpointCrateType){++checkpointHits;p.setCheckpoint(e.source.x,e.source.y);}
  else if(e.source.type==AkuCrateType)akuMasks=std::min(2u,akuMasks+1);
  else if(e.source.type==LifeCrateType)++extraLives;
  else if(reward&&repeatedTriggerCrate(e.source.type)&&e.triggerCap>e.hits){wumpaCollected+=e.triggerCap-e.hits;e.hits=e.triggerCap;}
 }
 void hurt(Player& p){++hazardHits;if(akuMasks)--akuMasks;else p.respawn();}
 void explode(RuntimeEntity& e,Player& p){
  if(!e.active)return;
  e.active=false;++crateBroken;effects.push_back({double(e.source.x),double(e.source.y),33,0});
  auto b=p.bodyBox();double cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2;if(std::hypot(cx-e.source.x,cy-e.source.y)<48.0)hurt(p);
  for(auto& other:items){if(!other.active||&other==&e||!isCrate(other.source.type))continue;if(std::hypot(double(other.source.x)-e.source.x,double(other.source.y)-e.source.y)>42.0)continue;
   if(nitroCrate(other.source.type)){other.active=false;++crateBroken;effects.push_back({double(other.source.x),double(other.source.y),35,0});}
   else if(tntCrate(other.source.type)){other.triggered=true;other.countdown=8;}
   else if(!metalCrate(other.source.type))breakCrate(other,p);
  }
 }
 unsigned effectLength(unsigned anim)const{if(anim>=crateClips.size()||crateClips[anim].frames.empty())return 1;return std::max(1u,crateClips[anim].duration)*unsigned(crateClips[anim].frames.size());}
 const Frame* clipFrame(unsigned anim,unsigned tick)const{if(anim>=crateClips.size())return nullptr;return clipFrame(crateClips[anim],tick);}
 static const Frame* clipFrame(const EntityClip& c,unsigned tick){if(c.frames.empty())return nullptr;size_t n=tick/std::max(1u,c.duration);n=(c.flags&2)?n%c.frames.size():std::min(n,c.frames.size()-1);return &c.frames[n];}
 static Frame decodeFramed(const GameData& data,const Bytes& asset,size_t p,unsigned paletteRecord){
  if(p+4>asset.size())throw std::runtime_error("Framed sprite header");
  unsigned wt=asset[p],ht=asset[p+1];if((wt!=1&&wt!=2&&wt!=4&&wt!=8)||(ht!=1&&ht!=2&&ht!=4&&ht!=8)||asset[p+2]!=0x10||asset[p+3]!=0)throw std::runtime_error("Framed sprite format");
  size_t bytes=size_t(wt)*ht*32;if(p+4+bytes>asset.size())throw std::runtime_error("Framed sprite data");Frame out;out.width=int(wt*8);out.height=int(ht*8);out.x=-out.width/2;out.y=-out.height/2;out.pixels.assign(size_t(out.width*out.height),0);
  std::array<uint32_t,16> colors{};uint32_t palette=data.rom.w(GameData::Table+8)+32*paletteRecord;for(unsigned i=0;i<16;i++)colors[i]=rgb555(data.rom.h(palette+2*i));
  const size_t base=p+4;for(unsigned ty=0;ty<ht;ty++)for(unsigned tx=0;tx<wt;tx++)for(unsigned y=0;y<8;y++)for(unsigned x=0;x<8;x++){size_t a=base+(ty*wt+tx)*32+y*4+x/2;unsigned v=(asset[a]>>((x&1)*4))&15;if(v)out.pixels[size_t((ty*8+y)*out.width+tx*8+x)]=colors[v];}
  return out;
 }
 void loadWumpaFrames(const GameData& data){
  Bytes asset=data.rom.tagged(0x080B1C60);if(asset.size()!=213064)throw std::runtime_error("Wumpa sheet revision");std::vector<size_t> offsets;size_t p=0;
  while(p<asset.size()){if(p+4>asset.size())throw std::runtime_error("Framed sheet tail");unsigned wt=asset[p],ht=asset[p+1];if((wt!=1&&wt!=2&&wt!=4&&wt!=8)||(ht!=1&&ht!=2&&ht!=4&&ht!=8)||asset[p+2]!=0x10||asset[p+3]!=0)throw std::runtime_error("Framed sheet revision");offsets.push_back(p);p+=4+size_t(wt)*ht*32;}
  if(p!=asset.size()||offsets.size()!=274)throw std::runtime_error("Framed sheet count");
  for(unsigned i=200;i<214;i++)wumpaFrames.push_back(decodeFramed(data,asset,offsets[i],33));
 }
 void loadCrateClips(const GameData& data){
  const auto& bank=data.banks.at(31);if(bank.animations.size()!=36)throw std::runtime_error("Crate animation count");
  for(unsigned ai=0;ai<bank.animations.size();++ai){const auto& a=bank.animations[ai];auto& clip=crateClips[ai];clip.duration=std::max(1u,a.duration);clip.flags=a.flags;for(unsigned fi:a.sequence)clip.frames.push_back(data.frame(31,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);crateBounds[ai]={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};}
 }
 void loadPlatformClip(const GameData& data){
  const auto& bank=data.banks.at(39);if(bank.animations.size()<=5)throw std::runtime_error("Level-object bank revision");const auto& a=bank.animations[5];platformClip.duration=std::max(1u,a.duration);platformClip.flags=a.flags;for(unsigned fi:a.sequence)platformClip.frames.push_back(data.frame(39,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);platformBounds={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};
 }
 static void pixel(std::vector<uint32_t>& c,int w,int h,int x,int y,uint32_t color){if(x>=0&&y>=0&&x<w&&y<h)c[size_t(y*w+x)]=color;}
 static void drawX(std::vector<uint32_t>& c,int w,int h,int x,int y){for(int i=0;i<5;i++){pixel(c,w,h,x+i,y+i,0xfff8f8f0);pixel(c,w,h,x+4-i,y+i,0xfff8f8f0);}}
 static void drawLetterA(std::vector<uint32_t>& c,int w,int h,int x,int y){for(int yy=0;yy<5;yy++)for(int xx=0;xx<4;xx++)if((yy==0&&xx>0&&xx<3)||(xx==0&&yy>0)||(xx==3&&yy>0)||(yy==2)){pixel(c,w,h,x+xx,y+yy,0xfff8e76c);}}
 static void drawDigit(std::vector<uint32_t>& c,int w,int h,int x,int y,unsigned d){
  static constexpr const char* pat[10]={"111101101101111","010110010010111","111001111100111","111001111001111","101101111001001","111100111001111","111100111101111","111001001001001","111101111101111","111101111001111"};const char* p=pat[d%10];
  for(int yy=0;yy<5;yy++)for(int xx=0;xx<3;xx++)if(p[yy*3+xx]=='1'){pixel(c,w,h,x+xx+1,y+yy+1,0xff101018);pixel(c,w,h,x+xx,y+yy,0xfff8e76c);}
 }
 static void drawNumber(std::vector<uint32_t>& c,int w,int h,int x,int y,unsigned value){std::array<unsigned,3> ds{(value/100)%10,(value/10)%10,value%10};unsigned first=value>=100?0:value>=10?1:2;for(unsigned i=first;i<3;i++)drawDigit(c,w,h,x+int((i-first)*5),y,ds[i]);}
};
}
