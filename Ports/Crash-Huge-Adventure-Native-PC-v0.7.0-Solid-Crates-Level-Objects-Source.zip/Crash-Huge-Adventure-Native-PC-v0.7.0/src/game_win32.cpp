#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <filesystem>
#include <memory>
#include <sstream>
#include <chrono>
#include "hd_assets.hpp"
namespace fs=std::filesystem;
static std::unique_ptr<crash::GameData> data;
static crash::Scene scene;
static std::unique_ptr<crash::Terrain> terrain;
static std::unique_ptr<crash::Player> player;
static std::unique_ptr<crash::EntityWorld> world;
static HWND hwnd;
static crash::ExternalSprites external;
static crash::DisplaySettings display;
static bool isFullscreen=false;
static std::vector<uint32_t> pixels;
static bool keys[256]{},paused=false,debug=false;
static double accumulator=0;
static std::chrono::steady_clock::time_point last;
void refresh(){
 pixels=crash::renderHD(*data,scene,*player,external,display.scale,display.external,debug,world.get());
 std::ostringstream title;title<<"Crash Native v0.7.0 | "<<240*display.scale<<"x"<<160*display.scale<<" | Wumpa "<<world->wumpaCollected<<'/'<<world->wumpaTotal<<" | Caixas "<<world->crateBroken<<'/'<<world->crateTotal<<" | PNG: "<<(display.external?external.sprites.size():0)<<(player->spinning()?" | GIRO":"")<<(paused?" | PAUSADO":"")<<" | x="<<int(player->x)<<" y="<<int(player->y);
 SetWindowTextA(hwnd,title.str().c_str());InvalidateRect(hwnd,nullptr,FALSE);
}
void fullscreen(){static WINDOWPLACEMENT old{};old.length=sizeof(WINDOWPLACEMENT);static LONG_PTR style=0;isFullscreen=!isFullscreen;if(isFullscreen){style=GetWindowLongPtrA(hwnd,GWL_STYLE);GetWindowPlacement(hwnd,&old);MONITORINFO mi{};mi.cbSize=sizeof(MONITORINFO);GetMonitorInfoA(MonitorFromWindow(hwnd,MONITOR_DEFAULTTONEAREST),&mi);SetWindowLongPtrA(hwnd,GWL_STYLE,style&~WS_OVERLAPPEDWINDOW);SetWindowPos(hwnd,HWND_TOP,mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right-mi.rcMonitor.left,mi.rcMonitor.bottom-mi.rcMonitor.top,SWP_FRAMECHANGED);}else{SetWindowLongPtrA(hwnd,GWL_STYLE,style);SetWindowPlacement(hwnd,&old);SetWindowPos(hwnd,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_FRAMECHANGED);}}
void reloadAssets(){external.load(*data,"assets/overrides");fs::create_directories("exports");external.report("exports/sprite-load-report.txt");}
void sizeWindow(){
 if(isFullscreen)return;
 RECT desired{0,0,240*display.scale,160*display.scale+72};AdjustWindowRect(&desired,WS_OVERLAPPEDWINDOW,FALSE);
 MONITORINFO mi{};mi.cbSize=sizeof(mi);GetMonitorInfoA(MonitorFromWindow(hwnd,MONITOR_DEFAULTTONEAREST),&mi);
 int width=std::min(int(desired.right-desired.left),int(mi.rcWork.right-mi.rcWork.left));int height=std::min(int(desired.bottom-desired.top),int(mi.rcWork.bottom-mi.rcWork.top));
 SetWindowPos(hwnd,nullptr,mi.rcWork.left+(mi.rcWork.right-mi.rcWork.left-width)/2,mi.rcWork.top+(mi.rcWork.bottom-mi.rcWork.top-height)/2,width,height,SWP_NOZORDER);
}
LRESULT CALLBACK proc(HWND w,UINT msg,WPARAM key,LPARAM param){try{switch(msg){
 case WM_KEYDOWN:
  if(key<256)keys[key]=true;
  if(param&(1LL<<30))return 0;
  if(key==VK_ESCAPE){DestroyWindow(w);return 0;}
  if(key==VK_F11)fullscreen();else if(key==VK_F5){reloadAssets();}else if(key==VK_F6){display.scale=display.scale==1?4:display.scale==4?6:1;sizeWindow();}else if(key=='H'){display.external=!display.external;}else if(key=='P'){paused=!paused;accumulator=0;}else if(key=='C')debug=!debug;else if(key=='R'){player->reset();world->reset();}
  refresh();return 0;
 case WM_KEYUP:if(key<256)keys[key]=false;return 0;
 case WM_KILLFOCUS:std::fill(std::begin(keys),std::end(keys),false);paused=true;accumulator=0;refresh();return 0;
 case WM_TIMER:{
  auto now=std::chrono::steady_clock::now();double dt=std::min(.1,std::chrono::duration<double>(now-last).count());last=now;
  if(!paused){accumulator+=dt;while(accumulator>=1.0/60){player->step({keys[VK_LEFT]||keys['A'],keys[VK_RIGHT]||keys['D'],keys[VK_SPACE]||keys['Z'],keys['X']||keys['K']});world->step(*player);accumulator-=1.0/60;}}
  refresh();return 0;}
 case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(w,&ps);RECT r;GetClientRect(w,&r);FillRect(dc,&r,static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
  int availableH=std::max(1,int(r.bottom)-72);int width=std::max(1,std::min(int(r.right),availableH*3/2)),height=std::max(1,width*2/3),x=(r.right-width)/2,y=(availableH-height)/2;
  int sourceW=240*display.scale,sourceH=160*display.scale;
  BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=sourceW;bi.bmiHeader.biHeight=-sourceH;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;
  SetStretchBltMode(dc,COLORONCOLOR);StretchDIBits(dc,x,y,width,height,0,0,sourceW,sourceH,pixels.data(),&bi,DIB_RGB_COLORS,SRCCOPY);SetTextColor(dc,RGB(225,230,245));SetBkMode(dc,TRANSPARENT);
  const char* lines[]={"SETAS / A,D: andar | ESPACO / Z: saltar | X / K: giro","P: pausa | R: reiniciar sala | C: terreno/corpo/ataque | F11: tela cheia | ESC: sair","F5: recarregar PNG | F6: 240 / 960 / 1440 | H: PNG / ROM | Wumpas + caixas ativos"};
  for(int i=0;i<3;i++)TextOutA(dc,12,availableH+8+20*i,lines[i],int(strlen(lines[i])));
  EndPaint(w,&ps);return 0;}
 case WM_SIZE:InvalidateRect(w,nullptr,FALSE);return 0;
 case WM_DESTROY:KillTimer(w,1);PostQuitMessage(0);return 0;
 }}catch(const std::exception& e){KillTimer(w,1);MessageBoxA(w,e.what(),"Crash Native - erro",MB_ICONERROR);DestroyWindow(w);return 0;}
 return DefWindowProcA(w,msg,key,param);
}
int WINAPI WinMain(HINSTANCE h,HINSTANCE,LPSTR,int show){try{
 SetProcessDPIAware();char path[MAX_PATH];GetModuleFileNameA(nullptr,path,MAX_PATH);fs::current_path(fs::path(path).parent_path());
 data=std::make_unique<crash::GameData>(crash::read("input/crash.gba"));scene=data->scene();terrain=std::make_unique<crash::Terrain>(*data,scene);player=std::make_unique<crash::Player>(*data,scene,*terrain);world=std::make_unique<crash::EntityWorld>(*data,scene);world->bind(*player);display=crash::settings("display.ini");reloadAssets();
 WNDCLASSA wc{};wc.lpfnWndProc=proc;wc.hInstance=h;wc.lpszClassName="CrashNativeGameplay";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassA(&wc);
 hwnd=CreateWindowA(wc.lpszClassName,"Crash Native v0.7.0",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,990,755,nullptr,nullptr,h,nullptr);if(!hwnd)throw std::runtime_error("Window creation failed");
 sizeWindow();refresh();last=std::chrono::steady_clock::now();SetTimer(hwnd,1,16,nullptr);ShowWindow(hwnd,show);MSG m;while(GetMessageA(&m,nullptr,0,0)>0){TranslateMessage(&m);DispatchMessageA(&m);}return 0;
 }catch(const std::exception& e){MessageBoxA(nullptr,e.what(),"Crash Native - erro",MB_ICONERROR);return 1;}}
