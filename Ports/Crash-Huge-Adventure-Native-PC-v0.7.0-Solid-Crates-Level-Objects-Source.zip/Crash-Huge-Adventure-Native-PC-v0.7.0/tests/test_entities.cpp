#include "../src/entities.hpp"
#include <cassert>
#include <iostream>
#include <algorithm>
#include <cmath>
int main(){try{using namespace crash;
 GameData data(read("input/crash.gba"));auto scene=data.scene();auto list=data.entities(scene);
 assert(list.size()==79);assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::WumpaType;})==26);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return EntityWorld::isCrate(e.type);})==40);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::LevelPlatformType;})==1);
 assert(EntityWorld::crateAnimation(21)==31); // wooden X crate
 assert(EntityWorld::crateAnimation(22)==26); // C/checkpoint crate
 assert(EntityWorld::crateAnimation(23)==23); // Aku crate
 assert(EntityWorld::crateAnimation(30)==28); // Crash/life crate
 assert(EntityWorld::crateAnimation(31)==5);  // Nitro
 assert(EntityWorld::crateAnimation(32)==0);  // ? crate
 assert(EntityWorld::crateAnimation(33)==25); // bounce/slatted crate
 assert(EntityWorld::crateAnimation(35)==17); // TNT
 auto spawn=std::find_if(list.begin(),list.end(),[](const Entity& e){return e.type==0;});assert(spawn!=list.end()&&spawn->x==31&&spawn->y==363);
 Terrain terrain(data,scene);Player p(data,scene,terrain);EntityWorld world(data,scene);world.bind(p);
 assert(world.items.size()==79&&world.wumpaPlaced==26&&world.wumpaTotal==71&&world.crateTotal==40&&world.platformTotal==1&&world.wumpaCollected==0&&world.crateBroken==0&&world.wumpaFrames.size()==14);
 assert(!world.platformClip.frames.empty());assert(std::abs((world.platformBounds[2]-world.platformBounds[0])-37.0)<.01);assert(std::abs((world.platformBounds[3]-world.platformBounds[1])-15.0)<.01);
 for(const auto& f:world.wumpaFrames){assert(f.width==32&&f.height==32);assert(std::any_of(f.pixels.begin(),f.pixels.end(),[](uint32_t v){return v!=0;}));}
 for(unsigned a:{0u,2u,5u,17u,23u,25u,26u,28u,31u,32u})assert(!world.crateClips[a].frames.empty());
 auto q5=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==5;});
 auto q10=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==10;});
 auto counter=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CounterCrateType;});
 assert(q5!=world.items.end()&&q10!=world.items.end()&&counter!=world.items.end()&&counter->triggerCap==5);
 // Exact collision boxes are read from the ROM animation records, not guessed from the sprite image.
 auto normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});assert(normal!=world.items.end());
 auto nb=world.entityBox(*normal);assert(std::abs((nb[2]-nb[0])-19.0)<.01&&std::abs((nb[3]-nb[1])-19.0)<.01);
 assert(p.dynamicSolids==&world.solids&&!world.solids.empty());
 // Wumpa collection.
 auto fruit=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::WumpaType;});assert(fruit!=world.items.end());
 p.x=fruit->source.x;p.y=fruit->source.y;world.step(p);assert(world.wumpaCollected>=1&&!fruit->active);auto before=world.wumpaCollected;world.step(p);assert(world.wumpaCollected==before);
 // A normal crate is destroyed by the native spin and creates a ROM-sprite break effect.
 world.reset();p.reset();normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});p.x=normal->source.x;p.y=normal->source.y;p.spinTicks=10;world.step(p);assert(!normal->active&&world.crateBroken>=1&&!world.effects.empty());
 // Metal crate survives the spin and participates in dynamic solid collision.
 world.reset();p.reset();auto metal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==28;});assert(metal!=world.items.end());p.x=metal->source.x;p.y=metal->source.y;p.spinTicks=10;world.step(p);assert(metal->active&&world.crateBroken==0);
 auto mb=world.entityBox(*metal);double floor= p.floorSurface(mb[0]+2,mb[2]-2,mb[1]-2,mb[1]+2);assert(std::abs(floor-mb[1])<.01);
 // Land on a metal box: the player stops exactly on its ROM collision top instead of passing through.
 p.spinTicks=0;p.x=metal->source.x;p.y=mb[1]-p.by-p.bh-8;p.vy=4;p.grounded=false;bool landed=false;for(int i=0;i<6;i++){p.step({});world.step(p);if(p.grounded){landed=true;break;}}assert(landed&&std::abs(p.feet()-mb[1])<.05);
 // Metal arrow crate is a solid bounce surface.
 world.reset();p.reset();auto arrow=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==29;});assert(arrow!=world.items.end());auto ab=world.entityBox(*arrow);p.x=arrow->source.x;p.y=ab[1]-p.by-p.bh-5;p.vy=4;p.grounded=false;bool bounced=false;for(int i=0;i<6;i++){p.step({});world.step(p);if(p.vy<0){bounced=true;break;}}assert(bounced);
 // ROM +6 cap: repeated trigger crate awards one Wumpa per valid landing and survives until the cap.
 world.reset();p.reset();q5=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==5;});auto qb=world.entityBox(*q5);unsigned wc=world.wumpaCollected;
 for(unsigned hit=0;hit<4;hit++){p.x=q5->source.x;p.y=qb[1]-p.by-p.bh;p.grounded=true;p.vy=0;p.lastDownImpact=3;world.step(p);assert(q5->active&&q5->hits==hit+1&&world.wumpaCollected==wc+hit+1);}
 p.x=q5->source.x;p.y=qb[1]-p.by-p.bh;p.grounded=true;p.vy=0;p.lastDownImpact=3;world.step(p);assert(!q5->active&&q5->hits==5&&world.wumpaCollected==wc+5);
 // C crate stores a native respawn checkpoint when broken.
 world.reset();p.reset();auto checkpoint=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CheckpointCrateType;});assert(checkpoint!=world.items.end());p.x=checkpoint->source.x;p.y=checkpoint->source.y;p.spinTicks=10;world.step(p);assert(!checkpoint->active&&world.checkpointHits==1&&p.checkpointActive&&p.checkpointX==checkpoint->source.x);
 auto savedX=p.checkpointX;p.x=10;p.y=terrain.height()+100;p.respawn();assert(p.respawns==1&&p.checkpointActive&&p.x==savedX);
 // Aku crate grants protection; first Nitro consumes it, second one respawns Crash.
 world.reset();p.reset();unsigned respawnBase=p.respawns;auto aku=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::AkuCrateType;});assert(aku!=world.items.end());p.x=aku->source.x;p.y=aku->source.y;p.spinTicks=10;world.step(p);assert(world.akuMasks==1);
 p.spinTicks=0;unsigned nx=unsigned(p.x),ny=unsigned(p.y);world.items.push_back({Entity{900,EntityWorld::NitroCrateType,nx,ny,0,0},true,0,0,false,0,0});auto& nitro1=world.items.back();world.step(p);assert(!nitro1.active&&world.akuMasks==0&&p.respawns==respawnBase&&world.hazardHits==1);
 nx=unsigned(p.x);ny=unsigned(p.y);world.items.push_back({Entity{901,EntityWorld::NitroCrateType,nx,ny,0,0},true,0,0,false,0,0});world.step(p);assert(!world.items.back().active&&p.respawns==respawnBase+1&&world.hazardHits==2);
 // TNT: spin arms a short fuse; its own ROM animation phases are available and it eventually explodes.
 p.x=500;p.y=200;p.spinTicks=10;world.items.push_back({Entity{902,EntityWorld::TntCrateType,500,200,0,0},true,0,0,false,0,0});size_t ti=world.items.size()-1;world.step(p);assert(world.items[ti].triggered&&world.items[ti].countdown==8);p.spinTicks=0;p.x=700;p.y=100;for(int i=0;i<8;i++)world.step(p);assert(!world.items[ti].active);
 // Type 86: first non-crate level object, rendered from bank 39 animation 5 and present in the solid set.
 auto platform=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::LevelPlatformType;});assert(platform!=world.items.end());auto pb=world.entityBox(*platform);assert(std::abs((pb[2]-pb[0])-37.0)<.01&&std::abs((pb[3]-pb[1])-15.0)<.01);
 // Reset + HUD/render path.
 world.reset();p.reset();assert(world.wumpaCollected==0&&world.crateBroken==0&&std::all_of(world.items.begin(),world.items.begin()+79,[](const RuntimeEntity& e){return e.active;}));
 std::vector<uint32_t> canvas(240*160,0xff101018);int camX=0,camY=250;world.renderLogical(canvas,240,160,camX,camY,true);assert(std::any_of(canvas.begin(),canvas.end(),[](uint32_t v){return v!=0xff101018;}));
 std::cout<<"Entity checks passed: 79 records, exact ROM crate boxes, stacked solids, 26 placed Wumpas + 45 ROM trigger-cap rewards, metal/bounce/checkpoint/Aku/Nitro/TNT, and type-86 bank-39 level object.\n";return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
