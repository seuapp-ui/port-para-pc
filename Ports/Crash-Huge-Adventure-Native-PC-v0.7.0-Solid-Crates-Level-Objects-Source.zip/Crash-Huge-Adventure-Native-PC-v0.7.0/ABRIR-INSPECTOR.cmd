@echo off
cd /d "%~dp0"
if not exist CrashNative-Inspector.exe (
 echo Executavel ausente. Execute COMPILAR-WINDOWS.cmd no terminal do Visual Studio.
 pause
 exit /b 1
)
start "" "%~dp0CrashNative-Inspector.exe"
