# Crash Bandicoot: The Huge Adventure — port nativo, v0.7.0

A v0.7.0 avança a primeira sala de demonstração para gameplay físico de verdade. O port continua sendo um runtime **C++ nativo para PC**: a ROM USA ACQE fornecida é usada como fonte de dados, mapas, paletas e sprites; o executável não roda código ARM e não emula o Game Boy Advance.

## O que funciona nesta versão

O Crash anda, corre, salta, faz salto curto, segue rampas, colide com paredes/teto, usa câmera, cai/respawna e possui giro com hitbox própria. A primeira sala interpreta seus 79 registros de entidade e mantém os 26 Wumpas colocados no mapa.

A família de caixas (tipos 21–39) continua ligada ao **banco 31**, mas agora deixou de ser apenas visual: o runtime lê a caixa física de cada animação diretamente da ROM. Na família usada aqui, o corpo efetivo das caixas mede 19×19 px. Isso permite ficar sobre caixas, andar sobre pilhas, ser bloqueado lateralmente e atingir caixas por baixo sem atravessar o sprite.

Também foram adicionados ou refinados:

- 40 caixas reais instanciadas na primeira sala;
- caixas metálicas sólidas e resistentes ao giro;
- caixa metálica com seta com impulso vertical;
- caixa listrada/bounce com impulso ao pousar e quebra por giro;
- caixa **C** como checkpoint e respawn;
- caixa de **Aku** com indicador no HUD e proteção simples;
- caixa de vida registrada no runtime;
- **Nitro** e **TNT** adaptados à colisão sólida, com dano/proteção, fusível e reação em cadeia simples;
- efeitos de quebra/explosão usando frames originais do banco 31;
- tipos **32 e 36** com contador de ativações lido diretamente do parâmetro da fase: os registros da primeira sala usam limites de 5 ou 10;
- 26 Wumpas colocados + 45 ativações possíveis desses registros, totalizando 71 no contador de teste desta etapa;
- primeiro objeto de nível fora da família de caixas: **tipo 86**, usando o **banco 39 / animação 5**, sprite original e caixa física de 37×15 px;
- objeto tipo 86 incluído na lista de sólidos, permitindo o Crash ficar apoiado nele;
- reset completo da sala com R.

## Fidelidade atual

A posição, o sprite e as caixas físicas das caixas/objeto 86 vêm da ROM real. O limite dos tipos 32/36 também é dado original: o construtor copia o byte `+6` do registro da fase para o campo de limite e a rotina original incrementa um contador até esse valor.

Ainda há reconstruções provisórias. Nesta versão cada ativação dos tipos 32/36 entrega um Wumpa; o comportamento do contador é confirmado, mas a rotina exata de recompensa ainda precisa ser fechada. O tipo 86 é sólido e visualmente correto para a primeira sala, porém ainda é tratado como estático. O sistema genérico de `mover` do original já foi identificado e será o próximo passo para plataformas móveis e outros objetos.

Inimigos completos, áudio, morte/dano finais, transição entre salas/fases, mapa, menus, save e progressão ainda não estão integralmente portados.

## Controles

| Tecla | Função |
|---|---|
| Esquerda / Direita, A / D | Andar |
| Espaço / Z | Saltar; solte cedo para salto curto |
| X / K | Giro / ataque |
| P | Pausar / continuar |
| R | Reiniciar a sala |
| C | Mostrar terreno, corpo e hitbox de ataque |
| F5 | Recarregar sprites PNG externos |
| F6 | Alternar 240×160 / 960×640 / 1440×960 |
| H | Alternar sprite externo / frame da ROM |
| F11 | Tela cheia |
| Esc | Sair |

A física roda a 60 Hz e continua sendo implementação nativa, sem frame de emulador por baixo.

## Dados principais usados

- Banco principal de sprites: `0x084A3624`.
- Banco de caixas: **31**, com 36 animações / 112 frames nesta ROM.
- Caixa física da família desta sala: 19×19 px, lida do registro da animação.
- Objeto tipo 86: banco **39**, animação **5**, corpo 37×15 px.
- Sheet das entidades do Wumpa: `0x080B1C60`, 213.064 bytes descomprimidos / 274 frames.
- Wumpa: frames 200–213, paleta record 33.
- Posição inicial: entidade tipo 0 em (31, 363).
- Animações do Crash usadas: 18 parado, 13 corrida, 31 ar e 16 giro.

`reports/v070-physics-map.csv` registra tipos, animações, corpos físicos e caps recuperados desta etapa. `reports/v070-gameplay/` contém o replay diagnóstico e `reports/v070-platform-preview.png` mostra o objeto tipo 86 com colisão.

## Testes

Execute `make test`. As quatro suítes devem passar:

- `TestCore`: LZ10, cores, tiles e chunk maps;
- `TestPlayer`: spawn, corpo, salto, rampas, paredes, teto, sweep, respawn, giro e sólidos dinâmicos;
- `TestEntities`: 79 entidades, Wumpas, 40 caixas, corpos físicos da ROM, empilhamento, caps 5/10, checkpoint, Aku, Nitro/TNT e objeto 86;
- `TestHD`: 330 comparações de frame/escala/espelhamento, alpha, crop, fallback, reload e configuração.

A entrega também é validada com AddressSanitizer + UndefinedBehaviorSanitizer no jogador/entidades e com o verificador independente C++/Python do renderer.

## Compilar no Windows

Dê duplo clique em `COMPILAR-WINDOWS.cmd`. O script procura automaticamente o Visual Studio 2022 / Build Tools, carrega `vcvars64.bat`, compila a versão atual e executa as suítes de teste. Depois use `ABRIR-JOGO.cmd`.

Este pacote não leva um `CrashNative.exe` antigo disfarçado de versão nova. Como este ambiente não possui MSVC, o EXE v0.7.0 é gerado no seu próprio Windows pelo script acima.

A ROM aceita pelo runtime é a USA ACQE validada no projeto. SHA-256 esperado: `6be639d1db218ca2bf2b1ff0ee0867334404cead5fb6684af4870d4644a15635`.

## Próxima evolução

O próximo passe deve integrar o **mover genérico** dos objetos de fase, começar os primeiros inimigos/objetos móveis com comportamento próprio e preparar a transição da sala atual para a próxima parte da fase.
