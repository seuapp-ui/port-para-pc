#!/usr/bin/env python3
"""Generate editable 4x PNG sheets from original ROM frames. No new HD artwork."""
import csv,json
from pathlib import Path
from PIL import Image
import extract_scene as e
root=e.ROOT;out=root/'assets/overrides';out.mkdir(parents=True,exist_ok=True)
bank=e.bank(0);rows=[];catalog=[];used=set()
for animation,name in [(18,'crash-idle'),(13,'crash-run'),(31,'crash-air'),(16,'crash-spin')]:
 a=bank['animations'][animation];palette=a['palette_record'];seq=list(dict.fromkeys(a['sequence']))
 sheet=Image.new('RGBA',(len(seq)*256,256))
 for cell,index in enumerate(seq):
  im,origin=e.frame(bank['frames'][index],e.pal(e.u(e.CONFIG['table']+8)+32*palette))
  tile=Image.new('RGBA',(64,64));tile.alpha_composite(im,(32+origin[0],40+origin[1]));sheet.alpha_composite(tile.resize((256,256),Image.Resampling.NEAREST),(cell*256,0))
  if (index,palette) not in used:
   rows.append([0,index,palette,f'{name}.png',cell*256,0,256,256,-32,-40,64,64]);used.add((index,palette))
  catalog.append({'animation':animation,'frame':index,'palette':palette,'sheet':f'{name}.png','cell':cell,'original_origin':list(origin),'original_dimensions':list(im.size)})
 sheet.save(out/f'{name}.png')
with (out/'manifest.csv').open('w',newline='',encoding='utf-8') as f:
 writer=csv.writer(f);writer.writerow(['bank','frame','palette','file','src_x','src_y','src_w','src_h','origin_x','origin_y','logical_width','logical_height']);writer.writerows(rows)
(root/'reports/replacement-template-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
print(f'{len(rows)} replacement mappings in four editable PNG sheets')
