#!/usr/bin/env python3
"""USA ACQE sprite-bank and level decoder, independently implemented from documented layouts.
Reference: https://github.com/Almamu/CrashBandicootXS-decomp
All offsets are discovered in the supplied ROM, not copied from Europe addresses.
"""
import json,struct,hashlib
from pathlib import Path
from PIL import Image,ImageDraw
BASE=0x08000000
ROOT=Path(__file__).resolve().parents[1]
R=(ROOT/'input/crash.gba').read_bytes()
def off(a,n=1):
 p=a-BASE
 if p<0 or p+n>len(R):raise ValueError(f'ROM address out of bounds {a:08X}')
 return p
def u(a):return struct.unpack_from('<I',R,off(a,4))[0]
def h(a):return struct.unpack_from('<H',R,off(a,2))[0]
def b(a):return R[off(a)]
def s(a):return struct.unpack_from('<h',R,off(a,2))[0]
def pal(a,count=16):
 return [tuple((((h(a+2*i)>>sh)&31)*255//31) for sh in (0,5,10)) for i in range(count)]
def lz(a):
 p=off(a,4);size=u(a)>>8
 if b(a)!=16 or not 0<size<=8*1024*1024:raise ValueError('Invalid LZ header')
 p+=4;o=bytearray()
 while len(o)<size:
  if p>=len(R):raise ValueError('truncated LZ flags')
  flags=R[p];p+=1
  for bit in range(7,-1,-1):
   if len(o)==size:break
   if flags>>bit&1:
    if p+2>len(R):raise ValueError('truncated LZ match')
    x,y=R[p:p+2];p+=2;d=((x&15)<<8)+y+1
    if d>len(o):raise ValueError('LZ distance')
    for j in range(min((x>>4)+3,size-len(o))):o.append(o[-d])
   else:
    if p>=len(R):raise ValueError('truncated LZ literal')
    o.append(R[p]);p+=1
 return bytes(o)
def tagged(a):
 if b(a)==0:
  n=u(a)>>8;return R[off(a+4,n):off(a+4,n)+n]
 return lz(a)
def locate():
 tables=[]
 for p in range(0,len(R)-16,4):
  x,t,f,n,k=struct.unpack_from('<IIIHH',R,p)
  if x==BASE+p+16 and n==56 and k==125 and BASE<t<f<BASE+len(R):tables.append(BASE+p)
 if len(tables)!=1:raise ValueError('sprite table not unique')
 dims=R.find(bytes([8,16,32,64,16,32,32,64,8,8,16,32,8,16,32,64,8,8,16,32,16,32,32,64]))
 pattern=struct.pack('<16H',0x83e0,0x9cc6,0x107f,0x0d04,0x0f9f,0x894c,0x0864,0x05d4,0x0abe,0xa27f,0x09be,0x1d5f,0x886b,0x94df,0x0c9b,0x0873)
 palette=R.find(pattern)
 level=R.find(struct.pack('<8I',1,1,355,275,233,4,4,0))
 if min(dims,palette,level)<0:raise ValueError('Expected USA data signatures absent')
 return {'table':tables[0],'dimensions':BASE+dims,'palette':BASE+palette,'levels':BASE+level}
CONFIG=locate();W=list(R[off(CONFIG['dimensions'],24):off(CONFIG['dimensions'])+12]);H=list(R[off(CONFIG['dimensions'])+12:off(CONFIG['dimensions'])+24]);COLORS=pal(CONFIG['palette'])
def bank(i):
 t=CONFIG['table'];a=u(t)+12*i;an,fr=u(a),u(a+4);n=h(a+10)
 ptrs=[];p=fr;first=BASE+len(R)
 while p<first:
  f=u(p);first=min(first,f);ptrs.append(f);p+=4
  if len(ptrs)>4096:raise ValueError('frame pointer count')
 if p!=first or len(ptrs)!=len(set(ptrs)):raise ValueError('invalid frame table')
 animations=[]
 for k in range(n):
  q=an+28*k;cnt=b(q+22);seq=[h(u(q)+2*j) for j in range(cnt)]
  if not seq or max(seq)>=len(ptrs):raise ValueError('animation sequence bounds')
  animations.append({'address':q,'palette_record':b(q+20),'duration':b(q+21),'flags':b(q+23),'sequence':seq})
 return {'index':i,'address':a,'frames':ptrs,'animations':animations}
def frame(addr,colors=COLORS):
 positions=u(addr);shapes=u(addr+4);packed=u(addr+8);count=packed>>24;src=u(CONFIG['table']+4)+(packed&0xffffff);pieces=[]
 for j in range(count):
  shape=b(shapes+j)&15
  if shape>=12:raise ValueError('OBJ shape')
  x,y=s(positions+4*j),s(positions+4*j+2);w,h_=W[shape],H[shape];n=w*h_//2
  raw=R[off(src,n):off(src,n)+n];im=Image.new('RGBA',(w,h_));px=im.load()
  for yy in range(h_):
   for xx in range(w):
    tile=(yy//8)*(w//8)+xx//8;v=raw[tile*32+(yy%8)*4+(xx%8)//2]>>((xx&1)*4)&15
    if v:px[xx,yy]=(*colors[v],255)
  pieces.append((x,y,im));src+=n
 if not pieces:return Image.new('RGBA',(1,1)),(0,0)
 x0=min(p[0] for p in pieces);y0=min(p[1] for p in pieces);x1=max(x+p.width for x,y,p in pieces);y1=max(y+p.height for x,y,p in pieces)
 if x1-x0>512 or y1-y0>512:raise ValueError('frame extent')
 out=Image.new('RGBA',(x1-x0,y1-y0))
 for x,y,p in pieces:out.alpha_composite(p,(x-x0,y-y0))
 return out,(x0,y0)
def chunk(asset,start):
 cells=[];p=start
 def take():
  nonlocal p
  if p+2>len(asset):raise ValueError('chunk truncated')
  value=int.from_bytes(asset[p:p+2],'little');p+=2;return value
 while len(cells)<128:
  token=take();n=token&255
  if n==0 or len(cells)+n>128:raise ValueError('chunk run size')
  if token&0x8000:cells.extend([take()]*n)
  elif token&0x4000:
   if n<3:raise ValueError('invalid delta run')
   value=take();cells.append(value);raw=asset[p:p+2*((n-1+1)//2)];p+=len(raw)
   if len(raw)!=2*((n-1+1)//2):raise ValueError('truncated delta')
   for d in raw[:n-1]:value=(value+(d if d<128 else d-256))&65535;cells.append(value)
  else:cells.extend(take() for _ in range(n))
 return cells
def room(level):
 info=CONFIG['levels']+36*level;lst=u(info+32);record=u(u(lst+4));palette=u(record);desc=u(record+4)
 if not desc:raise ValueError('actor category stage')
 asset=tagged(u(desc+20)) if b(desc+24) else R[off(u(desc+20)):]
 layers=[]
 for slot in range(5):
  a=u(desc+slot*4)
  if not a:continue
  grid,offset,tiles,sx,sy,cnt,gw,gh,wt,ht,last=struct.unpack_from('<IIIii6H',R,off(a,32))
  if last!=2 or not 0<gw*gh<65536:raise ValueError('layer bounds')
  ids=[h(grid+2*j) for j in range(gw*gh)];chunks={k:chunk(asset,offset+4*int.from_bytes(asset[offset+2*k:offset+2*k+2],'little')) for k in set(ids)}
  cells=[0]*(gw*16*gh*8)
  for cy in range(gh):
   for cx in range(gw):
    c=chunks[ids[cy*gw+cx]]
    for row in range(8):pos=(cy*8+row)*gw*16+cx*16;cells[pos:pos+16]=c[row*16:row*16+16]
  layers.append({'slot':slot,'address':a,'tile_data':tiles,'scale_x':sx,'scale_y':sy,'priority':cnt&3,'width_tiles':wt,'height_tiles':ht,'grid_width':gw,'grid_height':gh,'cells':cells})
 return {'level':level,'record':record,'descriptor':desc,'palette':palette,'asset':u(desc+20),'packed':b(desc+24),'entities':u(desc+28),'layers':layers}
def render_layer(layer,colors):
 if not layer['tile_data']:return None
 raw=tagged(layer['tile_data']);w=layer['width_tiles'];height=layer['height_tiles'];im=Image.new('RGBA',(w*8,height*8));px=im.load();eight=layer['slot']==3;stride=64 if eight else 32
 for ty in range(height):
  for tx in range(w):
   cell=layer['cells'][ty*layer['grid_width']*16+tx];tile=cell&(0x3fff if eight else 0x3ff);flipx=bool(cell&(0x4000 if eight else 0x400));flipy=bool(cell&(0x8000 if eight else 0x800));pb=0 if eight else (cell>>12)*16
   if (tile+1)*stride>len(raw):raise ValueError(f"tile out of bounds {tile} / {len(raw)//stride}")
   for y in range(8):
    for x in range(8):
     xx=7-x if flipx else x;yy=7-y if flipy else y;index=tile*stride+yy*(8 if eight else 4)+xx//(1 if eight else 2)
     v=raw[index] if eight else raw[index]>>((xx&1)*4)&15
     if v:px[tx*8+x,ty*8+y]=(*colors[pb+v],255)
 return im

def main():
 folder=ROOT/'assets/scene';folder.mkdir(exist_ok=True);banks=[bank(i) for i in range(56)];(ROOT/'reports/sprite-banks.json').write_text(json.dumps({'config':CONFIG,'banks':banks},indent=2))
 sheet=Image.new('RGBA',(8*112,7*112),(25,29,41,255));d=ImageDraw.Draw(sheet)
 for i,z in enumerate(banks):
  im,origin=frame(z['frames'][z['animations'][0]['sequence'][0]],pal(u(CONFIG['table']+8)+32*z['animations'][0]['palette_record']));im.thumbnail((100,85),Image.Resampling.NEAREST);x=i%8*112;y=i//8*112;sheet.alpha_composite(im,(x+(112-im.width)//2,y+8));d.text((x+8,y+95),f"Bank {i:02}",fill='white')
 sheet.save(ROOT/'reports/sprite-bank-catalog.png')
 # Render every frame in bank 0 for manual identification; no assumed action names.
 out=folder/'bank00';out.mkdir(exist_ok=True)
 for i,addr in enumerate(banks[0]['frames']):
  im,origin=frame(addr,pal(u(CONFIG['table']+8)));im.save(out/f'{i:03}.png')
 rm=room(0);colors=pal(rm['palette'],256)
 a=rm['entities'];count=h(a);groups=h(a+2);group_ptr=u(a+4);entities=[]
 for col in range(groups):
  n=h(group_ptr+col*8+2);ptr=u(group_ptr+col*8+4)
  for j in range(n):
   p=ptr+j*8;entities.append({'column':col,'type':h(p),'x':h(p+2),'y':h(p+4),'parameter_index':h(p+6),'address':hex(p)})
 if len(entities)!=count:raise ValueError('Entity group count mismatch')
 (ROOT/'reports/first-room-entities.json').write_text(json.dumps({'count':count,'groups':groups,'entities':entities,'behavior_implemented':False,'type_semantics':'unidentified ROM type indices'},indent=2))
 for lay in rm['layers']:
  image=render_layer(lay,colors)
  if image:image.save(folder/f"level00-layer{lay['slot']}.png")
  (folder/f"level00-layer{lay['slot']}.map.bin").write_bytes(struct.pack(f"<{len(lay['cells'])}H",*lay['cells']))
 report={**rm,'layers':[{k:v for k,v in x.items() if k!='cells'} for x in rm['layers']]};(ROOT/'reports/first-room.json').write_text(json.dumps(report,indent=2))
 preview=Image.new('RGBA',(480,320),(*colors[0],255))
 camera=(0,160)
 for lay in sorted([x for x in rm['layers'] if x['slot']<4],key=lambda x:(-x['priority'],-(x['slot']+1 if x['slot']<3 else 0))):
  image=Image.open(folder/f"level00-layer{lay['slot']}.png");cx=camera[0]*lay['scale_x']//256;cy=camera[1]*lay['scale_y']//256;preview.alpha_composite(image.crop((cx,cy,cx+480,cy+320)))
 preview.save(ROOT/'reports/first-room-preview.png')
 print(json.dumps({'config':{k:hex(v) for k,v in CONFIG.items()},'banks':len(banks),'frames':sum(len(b['frames']) for b in banks),'animations':sum(len(b['animations']) for b in banks),'first_room':hex(rm['descriptor']),'room_pixels':[(x['slot'],x['width_tiles']*8,x['height_tiles']*8) for x in rm['layers']],'bank0':{'frames':len(banks[0]['frames']),'animations':len(banks[0]['animations'])}},indent=2))
if __name__=='__main__':main()
